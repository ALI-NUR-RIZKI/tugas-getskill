<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
    $kode_obat = $_GET['id'];

    $query = "DELETE FROM obat WHERE kode_obat='$kode_obat'";
    if (mysqli_query($koneksi, $query)) {
        header("Location: index.php?status=deleted");
        exit();
    }
}
?>