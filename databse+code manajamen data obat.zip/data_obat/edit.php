<?php
include 'koneksi.php';

$kode_obat = $_GET['id'];
$query = mysqli_query($koneksi, "SELECT * FROM obat WHERE kode_obat='$kode_obat'");
$data = mysqli_fetch_array($query);

// Proses Update Data
if (isset($_POST['update'])) {
    $nama_obat = mysqli_real_escape_string($koneksi, $_POST['nama_obat']);
    $stok      = $_POST['stok'];
    $harga     = $_POST['harga'];

    $update_query = "UPDATE obat SET nama_obat='$nama_obat', stok='$stok', harga='$harga' WHERE kode_obat='$kode_obat'";
    
    if (mysqli_query($koneksi, $update_query)) {
        header("Location: index.php?status=updated");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Data Obat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container my-5" style="max-width: 600px;">
        <div class="card shadow-sm">
            <div class="card-header bg-warning text-dark">
                <h5 class="card-title m-0">Edit Data Obat</h5>
            </div>
            <div class="card-body">
                <form action="" method="POST">
                    <div class="mb-3">
                        <label class="form-label">Nama Obat</label>
                        <input type="text" name="nama_obat" class="form-control" value="<?= $data['nama_obat']; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Stok</label>
                        <input type="number" name="stok" class="form-control" value="<?= $data['stok']; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Harga (Rp)</label>
                        <input type="number" name="harga" class="form-control" value="<?= $data['harga']; ?>" required>
                    </div>
                    <button type="submit" name="update" class="btn btn-primary">Simpan Perubahan</button>
                    <a href="index.php" class="btn btn-secondary">Batal</a>
                </form>
            </div>
        </div>
    </div>
</body>
</html>