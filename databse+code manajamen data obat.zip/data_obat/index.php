<?php
include 'koneksi.php';

// Fitur CREATE (Simpan Data Baru)
if (isset($_POST['simpan'])) {
    $nama_obat = mysqli_real_escape_string($koneksi, $_POST['nama_obat']);
    $stok      = $_POST['stok'];
    $harga     = $_POST['harga'];

    $query = "INSERT INTO obat (nama_obat, stok, harga) VALUES ('$nama_obat', '$stok', '$harga')";
    if (mysqli_query($koneksi, $query)) {
        header("Location: index.php?status=success");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Manajemen Data Obat</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

    <div class="container my-5">
        <h2 class="mb-4 text-center fw-bold">Manajemen Data Obat</h2>

        <!-- FORM CREATE (Tambah Data) -->
        <div class="card mb-5 shadow-sm border-0">
            <div class="card-header bg-primary text-white">
                <h5 class="card-title m-0">Form Tambah Obat</h5>
            </div>
            <div class="card-body">
                <form action="index.php" method="POST">
                    <div class="mb-3">
                        <label class="form-label">Nama Obat</label>
                        <input type="text" name="nama_obat" class="form-control" placeholder="Contoh: Paracetamol 500mg" required>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Stok</label>
                            <input type="number" name="stok" class="form-control" placeholder="Jumlah stok" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Harga (Rp)</label>
                            <input type="number" name="harga" class="form-control" placeholder="Harga obat" required>
                        </div>
                    </div>
                    <button type="submit" name="simpan" class="btn btn-success">Tambah Data</button>
                </form>
            </div>
        </div>

        <!-- TABEL READ (Tampil Data + Tombol Edit & Delete) -->
        <div class="card shadow-sm border-0">
            <div class="card-header bg-dark text-white">
                <h5 class="card-title m-0">Daftar Stok Obat</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover align-middle">
                        <thead class="table-secondary">
                            <tr>
                                <th>Kode Obat</th>
                                <th>Nama Obat</th>
                                <th>Stok</th>
                                <th>Harga</th>
                                <th class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Fitur READ
                            $sql = "SELECT * FROM obat ORDER BY kode_obat DESC";
                            $result = mysqli_query($koneksi, $sql);

                            if (mysqli_num_rows($result) > 0) {
                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo "<tr>";
                                    echo "<td>" . $row['kode_obat'] . "</td>";
                                    echo "<td>" . $row['nama_obat'] . "</td>";
                                    echo "<td>" . $row['stok'] . "</td>";
                                    echo "<td>Rp " . number_format($row['harga'], 0, ',', '.') . "</td>";
                                    echo "<td class='text-center'>
                                            <a href='edit.php?id=" . $row['kode_obat'] . "' class='btn btn-warning btn-sm me-1'>Edit</a>
                                            <a href='hapus.php?id=" . $row['kode_obat'] . "' class='btn btn-danger btn-sm' onclick=\"return confirm('Yakin ingin menghapus data ini?')\">Hapus</a>
                                          </td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='5' class='text-center text-muted'>Belum ada data obat tersimpan.</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

    <!-- Bootstrap 5 JS -->
    <script href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>