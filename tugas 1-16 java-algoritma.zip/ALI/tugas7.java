import java.util.Scanner;

public class tugas7 {

    // Method fungsi untuk melakukan Selection Sort secara ascending dari kiri
    public static void selectionSortAscending(int[] arr) {
        int n = arr.length;
        
        // Perulangan bergerak dari indeks paling kiri (0) ke kanan (n-2)
        for (int i = 0; i < n - 1; i++) {
            int minIdx = i; // Asumsikan indeks ke-i adalah nilai terkecil

            // Cari nilai terkecil pada sub-array di sebelah kanan indeks i
            for (int j = i + 1; j < n; j++) {
                if (arr[j] < arr[minIdx]) {
                    minIdx = j; // Simpan indeks nilai terkecil
                }
            }

            // Tukar posisi nilai terkecil ke posisi kiri (indeks i)
            if (minIdx != i) {
                int temp = arr[minIdx];
                arr[minIdx] = arr[i];
                arr[i] = temp;
            }
        }
    }

    // Method penolong untuk menampilkan elemen-elemen array
    public static void tampilkanArray(int[] arr) {
        for (int val : arr) {
            System.out.print(val + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // 1. Input jumlah data dari user
        System.out.print("Masukkan jumlah data yang ingin diinputkan: ");
        int jumlahData = scanner.nextInt();

        // Deklarasi array sesuai jumlah data yang diinputkan
        int[] data = new int[jumlahData];

        // 2. Input nilai tiap elemen array dari user
        System.out.println("Masukkan " + jumlahData + " angka:");
        for (int i = 0; i < jumlahData; i++) {
            System.out.print("Data ke-" + (i + 1) + ": ");
            data[i] = scanner.nextInt();
        }

        // Menampilkan data sebelum diurutkan
        System.out.print("\nData awal: ");
        tampilkanArray(data);

        // 3. Memanggil method sorting untuk memproses array dinamis
        selectionSortAscending(data);

        // Menampilkan data setelah diurutkan
        System.out.print("Hasil Sorting Ascending (dari kiri): ");
        tampilkanArray(data);

        scanner.close();
    }
}