import java.util.Scanner;

public class tugas13 {

    // Method dinamis untuk pencarian Sequential Search pada data bertipe String
    public static void cariNama(String[] arr, String key) {
        boolean ditemukan = false;
        int indeksDitemukan = -1;

        // Perulangan untuk memeriksa tiap elemen array String
        for (int i = 0; i < arr.length; i++) {
            // Menggunakan equalsIgnoreCase agar pencarian bersifat case-insensitive
            if (arr[i].equalsIgnoreCase(key)) {
                ditemukan = true;
                indeksDitemukan = i;
                break; // Hentikan perulangan jika data sudah ditemukan
            }
        }

        // Menampilkan hasil pencarian
        if (ditemukan) {
            System.out.println("Data \"" + arr[indeksDitemukan] + "\" DITEMUKAN pada indeks ke-" + indeksDitemukan + " (Posisi ke-" + (indeksDitemukan + 1) + ").");
        } else {
            System.out.println("Data \"" + key + "\" TIDAK DITEMUKAN dalam array.");
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Contoh array bertipe String (dapat diganti dengan data array String apapun)
        String[] daftarSiswa = {"Misbahul", "Andre", "Ivan", "Andika", "Riyan", "Afrizal"};

        // Menampilkan data array
        System.out.print("Daftar Data Array (String): ");
        for (int i = 0; i < daftarSiswa.length; i++) {
            System.out.print(daftarSiswa[i] + (i < daftarSiswa.length - 1 ? ", " : ""));
        }
        System.out.println();

        // Meminta input key (String) dari pengguna
        System.out.print("Masukkan kata/nama yang dicari (key): ");
        String key = scanner.nextLine();

        // Memanggil method dinamis dengan mengirimkan array String dan key
        cariNama(daftarSiswa, key);

        scanner.close();
    }
}