import java.util.Scanner;

public class tugas4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Meminta input jumlah deret dari pengguna
        System.out.print("Masukkan jumlah deret: ");
        int n = scanner.nextInt();

        // Inisialisasi angka awal dan penambah
        int nilai = 3;
        int penambah = 2;

        System.out.print("Output: ");

        // Perulangan untuk menampilkan deret sebanyak n suku
        for (int i = 1; i <= n; i++) {
            System.out.print(nilai + " ");

            // Nilai ditambah dengan penambah saat ini
            nilai = nilai + penambah;

            // Nilai penambah bertambah 1 setiap putaran
            penambah++;
        }

        scanner.close();
    }
}