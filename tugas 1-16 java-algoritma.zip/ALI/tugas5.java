import java.util.Arrays;

public class tugas5 {
    public static void main(String[] args) {
        // Inisialisasi data array sesuai soal
        int[] data = {27, 80, 8, 46, 16, 12, 50};

        // Menampilkan data sebelum diurutkan
        System.out.println("Data sebelum diurutkan: " + Arrays.toString(data));

        // Proses pengurutan ascending (Bubble Sort)
        for (int i = 0; i < data.length - 1; i++) {
            for (int j = 0; j < data.length - 1 - i; j++) {
                // Mengubah posisi jika elemen kiri lebih besar dari elemen kanan
                if (data[j] > data[j + 1]) {
                    int temp = data[j];
                    data[j] = data[j + 1];
                    data[j + 1] = temp;
                }
            }
        }

        // Menampilkan deret data setelah diurutkan
        System.out.print("Deret data setelah diurutkan (ascending): ");
        for (int i = 0; i < data.length; i++) {
            System.out.print(data[i] + " ");
        }
    }
}