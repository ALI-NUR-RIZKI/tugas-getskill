import java.util.Scanner;

public class tugas3 {

    // Fungsi rekursif untuk mencari nilai suku ke-n Fibonacci
    public static int fibonacci(int n) {
        // Base case: suku ke-0 adalah 0, suku ke-1 adalah 1
        if (n <= 0) {
            return 0;
        } else if (n == 1) {
            return 1;
        } 
        // Recursive step: f(n) = f(n-1) + f(n-2)
        else {
            return fibonacci(n - 1) + fibonacci(n - 2);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Meminta input jumlah deret dari pengguna
        System.out.print("Masukkan jumlah deret Fibonacci: ");
        int jumlah = scanner.nextInt();

        System.out.print("Deret Fibonacci (" + jumlah + " suku): ");

        // Perulangan untuk mencetak deret dari suku ke-1 hingga suku ke-jumlah
        for (int i = 1; i <= jumlah; i++) {
            System.out.print(fibonacci(i) + " ");
        }

        scanner.close();
    }
}