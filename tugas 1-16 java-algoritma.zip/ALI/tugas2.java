import java.util.Scanner;

public class tugas2 {

    // Fungsi rekursif untuk menghitung faktorial
    public static long hitungFaktorial(int n) {
        // Base case: jika n <= 1, faktorial adalah 1
        if (n <= 1) {
            return 1;
        } 
        // Recursive step: n * faktorial(n - 1)
        else {
            return n * hitungFaktorial(n - 1);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Meminta input angka dari pengguna
        System.out.print("Masukkan angka untuk menghitung faktorial: ");
        int angka = scanner.nextInt();

        // Validasi jika pengguna memasukkan angka negatif
        if (angka < 0) {
            System.out.println("Angka harus bernilai 0 atau positif.");
        } else {
            // Memanggil fungsi rekursif dan menyimpan hasilnya
            long hasil = hitungFaktorial(angka);
            System.out.println("Hasil " + angka + "! = " + hasil);
        }

        scanner.close();
    }
}