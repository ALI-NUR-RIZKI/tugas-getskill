import java.util.Arrays;
import java.util.Scanner;

public class tugas14 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Data array sesuai instruksi tugas
        int[] data = {85, 30, 55, 80, 100, 65, 35, 20, 70, 65, 10, 40, 82, 90};

        System.out.println("Data Awal: " + Arrays.toString(data));

        // Syarat Binary Search: Data harus terurut secara Ascending
        Arrays.sort(data);
        System.out.println("Data Setelah Diurutkan: " + Arrays.toString(data));

        // Meminta input key (angka yang dicari) dari pengguna
        System.out.print("\nMasukkan angka yang ingin dicari (key): ");
        int key = scanner.nextInt();

        // Inisialisasi variabel indeks pencarian
        int low = 0;
        int high = data.length - 1;
        boolean ditemukan = false;
        int indeksDitemukan = -1;

        // Algoritma Binary Search
        while (low <= high) {
            int mid = low + (high - low) / 2; // Menentukan titik tengah

            if (data[mid] == key) {
                ditemukan = true;
                indeksDitemukan = mid;
                break; // Hentikan pencarian jika data ditemukan
            } else if (data[mid] < key) {
                low = mid + 1; // Cari di setengah bagian kanan
            } else {
                high = mid - 1; // Cari di setengah bagian kiri
            }
        }

        // Menampilkan hasil pencarian
        System.out.println();
        if (ditemukan) {
            System.out.println("Angka " + key + " DITEMUKAN pada indeks ke-" + indeksDitemukan + " (setelah pengurutan).");
        } else {
            System.out.println("Angka " + key + " TIDAK DITEMUKAN dalam array.");
        }

        scanner.close();
    }
}