import java.util.Scanner;

public class tugas11 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Data array nama siswa sesuai instruksi tugas
        String[] siswa = {"Misbahul", "Andre", "Ivan", "Andika", "Riyan", "Afrizal"};

        // Menampilkan daftar nama siswa
        System.out.print("Daftar Nama Siswa: ");
        for (int i = 0; i < siswa.length; i++) {
            System.out.print(siswa[i] + (i < siswa.length - 1 ? ", " : ""));
        }
        System.out.println();

        // Meminta input nama yang dicari dari user
        System.out.print("Masukkan nama siswa yang dicari: ");
        String key = scanner.nextLine();

        boolean ditemukan = false;
        int indeksDitemukan = -1;

        // Proses Sequential Search pada Array String
        for (int i = 0; i < siswa.length; i++) {
            // Menggunakan equalsIgnoreCase() untuk membandingkan isi string (case-insensitive)
            if (siswa[i].equalsIgnoreCase(key)) {
                ditemukan = true;
                indeksDitemukan = i;
                break; // Berhenti mencari jika data ditemukan
            }
        }

        // Menampilkan hasil pencarian
        if (ditemukan) {
            System.out.println("Siswa bernama \"" + siswa[indeksDitemukan] + "\" DITEMUKAN pada indeks ke-" + indeksDitemukan + " (Posisi ke-" + (indeksDitemukan + 1) + ").");
        } else {
            System.out.println("Siswa dengan nama \"" + key + "\" TIDAK DITEMUKAN dalam daftar.");
        }

        scanner.close();
    }
}