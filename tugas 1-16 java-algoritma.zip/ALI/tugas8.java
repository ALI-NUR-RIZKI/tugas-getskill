import java.util.ArrayList;
import java.util.Scanner;

public class tugas8 {

    // Method untuk melakukan Selection Sort (Descending) pada ArrayList
    public static void selectionSortDescending(ArrayList<Integer> list) {
        int n = list.size();

        for (int i = 0; i < n - 1; i++) {
            int maxIdx = i; // Asumsikan indeks ke-i adalah nilai terbesar

            // Cari nilai terbesar pada elemen setelah i
            for (int j = i + 1; j < n; j++) {
                if (list.get(j) > list.get(maxIdx)) {
                    maxIdx = j; // Simpan indeks nilai terbesar
                }
            }

            // Penukaran (swap) elemen jika ditemukan nilai yang lebih besar
            if (maxIdx != i) {
                int temp = list.get(maxIdx);
                list.set(maxIdx, list.get(i));
                list.set(i, temp);
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Integer> data = new ArrayList<>();

        // Input jumlah data dari user
        System.out.print("Masukkan jumlah data yang ingin diinputkan: ");
        int jumlahData = scanner.nextInt();

        // Input angka-angka ke dalam ArrayList
        System.out.println("Masukkan " + jumlahData + " angka:");
        for (int i = 0; i < jumlahData; i++) {
            System.out.print("Data ke-" + (i + 1) + ": ");
            data.add(scanner.nextInt());
        }

        // Menampilkan data sebelum diurutkan
        System.out.println("\nData awal: " + data);

        // Memanggil method sorting dengan parameter ArrayList
        selectionSortDescending(data);

        // Menampilkan data setelah diurutkan secara descending
        System.out.println("Hasil Selection Sort Descending: " + data);

        scanner.close();
    }
}