import java.util.Scanner;

public class tugas12 {

    // Method void untuk pencarian sequential search dinamis
    // Menerima parameter data array (int[]) dan key yang dicari (int)
    public static void cariAngka(int[] arr, int key) {
        boolean ditemukan = false;
        int indeksDitemukan = -1;

        // Proses pencarian berurutan
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == key) {
                ditemukan = true;
                indeksDitemukan = i;
                break; // Hentikan pencarian jika angka sudah ditemukan
            }
        }

        // Menampilkan hasil pencarian
        if (ditemukan) {
            System.out.println("Angka " + key + " DITEMUKAN pada indeks ke-" + indeksDitemukan + " (Posisi ke-" + (indeksDitemukan + 1) + ").");
        } else {
            System.out.println("Angka " + key + " TIDAK DITEMUKAN dalam array.");
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Contoh data array (dapat diganti dengan data array apapun)
        int[] dataArray = {12, 45, 23, 89, 34, 67, 10, 50};

        // Menampilkan elemen array
        System.out.print("Data Array: ");
        for (int i = 0; i < dataArray.length; i++) {
            System.out.print(dataArray[i] + " ");
        }
        System.out.println();

        // Meminta input key dari user
        System.out.print("Masukkan angka yang dicari (key): ");
        int key = scanner.nextInt();

        // Memanggil method void dengan mengirimkan data array dan key sebagai parameter
        cariAngka(dataArray, key);

        scanner.close();
    }
}