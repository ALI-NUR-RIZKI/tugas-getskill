import java.util.Scanner;

public class tugas10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Data array contoh dari tugas sebelumnya
        int[] data = {5, 6, 9, 2, 8, 1, 7};

        // Menampilkan elemen array
        System.out.print("Data Array: ");
        for (int i = 0; i < data.length; i++) {
            System.out.print(data[i] + " ");
        }
        System.out.println();

        // Input key yang ingin dicari
        System.out.print("Masukkan angka yang ingin dicari (key): ");
        int key = scanner.nextInt();

        // Variabel pembantu bertipe boolean dengan nilai awal false
        boolean ditemukan = false;
        int indeksDitemukan = -1;

        // Perulangan pencarian data (Sequential Search)
        for (int i = 0; i < data.length; i++) {
            if (data[i] == key) {
                ditemukan = true;       // Mengubah nilai menjadi true jika data ditemukan
                indeksDitemukan = i;
                break;                  // Hentikan perulangan jika sudah ketemu
            }
        }

        // Percabangan untuk mengecek hasil pencarian
        if (ditemukan) {
            System.out.println("Angka " + key + " ditemukan pada indeks ke-" + indeksDitemukan);
        } else {
            // Ditampilkan jika nilai boolean 'ditemukan' tetap false
            System.out.println("Angka yang dicari tidak ditemukan di dalam data array");
        }

        scanner.close();
    }
}