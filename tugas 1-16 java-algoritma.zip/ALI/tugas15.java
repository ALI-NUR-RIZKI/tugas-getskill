import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class tugas15 {

    /**
     * Method reusable untuk melakukan Binary Search.
     * Mengembalikan indeks tempat data ditemukan, atau -1 jika tidak ditemukan.
     */
    public static int binarySearch(int[] arr, int key) {
        int low = 0;
        int high = arr.length - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2;

            if (arr[mid] == key) {
                return mid; // Key ditemukan pada indeks mid
            } else if (arr[mid] < key) {
                low = mid + 1; // Cari di setengah bagian kanan
            } else {
                high = mid - 1; // Cari di setengah bagian kiri
            }
        }

        return -1; // Key tidak ditemukan
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        // 1. Input jumlah elemen array secara variatif dari user
        System.out.print("Masukkan jumlah elemen array: ");
        int n = scanner.nextInt();

        int[] data = new int[n];

        // 2. Mengisi array dengan angka acak (misal: rentang 1 - 100)
        for (int i = 0; i < n; i++) {
            data[i] = random.nextInt(100) + 1;
        }

        System.out.println("\nData Acak Awal: " + Arrays.toString(data));

        // 3. Syarat Binary Search: Data wajib diurutkan terlebih dahulu
        Arrays.sort(data);
        System.out.println("Data Setelah Diurutkan: " + Arrays.toString(data));

        // 4. Meminta input key dari user
        System.out.print("\nMasukkan angka yang dicari (key): ");
        int key = scanner.nextInt();

        // 5. Memanggil method Binary Search
        int hasil = binarySearch(data, key);

        // Menampilkan hasil pencarian
        if (hasil != -1) {
            System.out.println("Angka " + key + " DITEMUKAN pada indeks ke-" + hasil + " (setelah pengurutan).");
        } else {
            System.out.println("Angka " + key + " TIDAK DITEMUKAN dalam array.");
        }

        scanner.close();
    }
}