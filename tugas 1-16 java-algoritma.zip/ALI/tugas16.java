import java.util.Arrays;
import java.util.Scanner;

public class tugas16 {

    // 1. Sequential Search (bisa langsung pada data tidak terurut)
    public static int sequentialSearch(int[] arr, int key) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == key) {
                return i;
            }
        }
        return -1;
    }

    // 2. Binary Search (syarat: array harus diurutkan terlebih dahulu)
    public static int binarySearch(int[] arr, int key) {
        int low = 0;
        int high = arr.length - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2;
            if (arr[mid] == key) {
                return mid;
            } else if (arr[mid] < key) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Data awal dari soal (unsorted)
        int[] dataAwal = {
            9, 6, 4, 3, 7, 1, 6, 10, 20, 61, 43, 80, 100, 54, 32, 36, 75, 81, 
            17, 19, 1020, 55, 57, 82, 84, 16, 21, 28, 99, 89, 87, 73, 74, 76, 78, 79, 83, 85
        };

        System.out.println("Jumlah data: " + dataAwal.length);
        System.out.print("Masukkan angka yang dicari (key): ");
        int key = scanner.nextInt();

        // --- UJI SEQUENTIAL SEARCH ---
        long startTimeSeq = System.nanoTime();
        int hasilSeq = sequentialSearch(dataAwal, key);
        long endTimeSeq = System.nanoTime();
        long durasiSeq = endTimeSeq - startTimeSeq;

        // --- UJI BINARY SEARCH ---
        // Karena data awal unsorted, dihitung pula waktu pengurutan (sorting)
        long startTimeBin = System.nanoTime();
        
        int[] dataSorted = dataAwal.clone(); // Salin array agar tidak merusak data awal
        Arrays.sort(dataSorted);             // Wajib diurutkan lebih dulu
        int hasilBin = binarySearch(dataSorted, key);
        
        long endTimeBin = System.nanoTime();
        long durasiBin = endTimeBin - startTimeBin;

        // --- TAMPILKAN HASIL ---
        System.out.println("\n================ HASIL ANALISIS ================");
        System.out.println("1. Sequential Search:");
        System.out.println("   - Status            : " + (hasilSeq != -1 ? "Ditemukan (indeks " + hasilSeq + ")" : "Tidak Ditemukan"));
        System.out.println("   - Waktu Eksekusi   : " + durasiSeq + " ns");

        System.out.println("\n2. Binary Search (Termasuk Sorting):");
        System.out.println("   - Status            : " + (hasilBin != -1 ? "Ditemukan (indeks " + hasilBin + ")" : "Tidak Ditemukan"));
        System.out.println("   - Waktu Eksekusi   : " + durasiBin + " ns");
        System.out.println("================================================");

        scanner.close();
    }
}