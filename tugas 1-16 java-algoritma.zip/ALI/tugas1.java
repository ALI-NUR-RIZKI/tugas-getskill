import java.util.Scanner;

public class tugas1 {

    // Fungsi rekursif untuk menghitung perpangkatan (basis^pangkat)
    public static int hitungPangkat(int basis, int pangkat) {
        // Base case: bilangan pangkat 0 selalu bernilai 1
        if (pangkat == 0) {
            return 1;
        }
        // Recursive step: basis * (basis^(pangkat - 1))
        else {
            return basis * hitungPangkat(basis, pangkat - 1);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Meminta input angka yang akan dipangkatkan
        System.out.print("Masukkan angka yang akan dipangkatkan: ");
        int angka = scanner.nextInt();

        // Meminta input nilai pangkat
        System.out.print("Masukkan nilai pangkat: ");
        int pangkat = scanner.nextInt();

        // Memanggil fungsi rekursif dan menyimpan hasilnya
        int hasil = hitungPangkat(angka, pangkat);

        // Menampilkan hasil
        System.out.println("\nHasil dari " + angka + "^" + pangkat + " = " + hasil);

        scanner.close();
    }
}