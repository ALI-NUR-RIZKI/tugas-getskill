import java.util.Arrays;

public class tugas6 {
    public static void main(String[] args) {
        // Data array contoh
        int[] data = {27, 80, 8, 46, 16, 12, 50};

        System.out.println("Data awal: " + Arrays.toString(data));

        // Selection Sort dari Kanan ke Kiri (Ascending)
        // Perulangan i bergerak dari indeks paling kanan ke kiri (data.length - 1 hingga 1)
        for (int i = data.length - 1; i > 0; i--) {
            int maxIdx = i; // Asumsikan elemen di indeks 'i' adalah nilai maksimal

            // Cari indeks dengan nilai terbesar di sub-array [0 ... i-1]
            for (int j = 0; j < i; j++) {
                if (data[j] > data[maxIdx]) {
                    maxIdx = j; // Simpan indeks nilai maksimal yang ditemukan
                }
            }

            // Tukar elemen terbesar (data[maxIdx]) dengan elemen di posisi kanan (data[i])
            if (maxIdx != i) {
                int temp = data[maxIdx];
                data[maxIdx] = data[i];
                data[i] = temp;
            }
        }

        // Menampilkan hasil pengurutan
        System.out.print("Hasil Selection Sort dari Kanan ke Kiri (Ascending): ");
        for (int val : data) {
            System.out.print(val + " ");
        }
    }
}