import java.util.Scanner;

public class tugas9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Deklarasi array sesuai instruksi soal
        int[] data = {5, 6, 9, 2, 8, 1, 7};

        // Menampilkan elemen array
        System.out.print("Data Array: ");
        for (int i = 0; i < data.length; i++) {
            System.out.print(data[i] + " ");
        }
        System.out.println();

        // Meminta input key (angka yang dicari) dari pengguna
        System.out.print("Masukkan angka yang ingin dicari (key): ");
        int key = scanner.nextInt();

        boolean ditemukan = false;
        int indeksDitemukan = -1;

        // Proses Sequential Search (Pencarian berurutan satu per satu)
        for (int i = 0; i < data.length; i++) {
            if (data[i] == key) {
                ditemukan = true;
                indeksDitemukan = i;
                break; // Berhenti mencari jika data sudah ditemukan
            }
        }

        // Menampilkan hasil pencarian
        if (ditemukan) {
            System.out.println("Data " + key + " DITEMUKAN pada indeks ke-" + indeksDitemukan + " (Posisi ke-" + (indeksDitemukan + 1) + ")");
        } else {
            System.out.println("Data " + key + " TIDAK DITEMUKAN dalam array.");
        }

        scanner.close();
    }
}