<html>
    <head>
        <title>Siswa</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="container md-6 mt-4 bg-light">
            <h1>TABEL SISWA</h1>
            <a href="tambah_siswa.php" class="btn btn-sm btn-primary float-left">Tambah</a>
            <br>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>NO</th>
                            <th>No Induk</th>
                            <th>Nama</th>
                            <th>Jenis Kelamin</th>
                            <th>No Telepon</th>
                            <th>Alamat</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include('koneksi.php');
                        $no = 1;

                        $result = mysqli_query($mysqli, "SELECT * FROM siswa ORDER BY id DESC");
                        while($user_data = mysqli_fetch_array($result)){
                        ?>
                        <tr>
                            <td><?php echo $no++ ?></td>
                            <td><?php echo $user_data['no_induk'] ?></td>
                            <td><?php echo $user_data['nama'] ?></td>
                            <td><?php echo $user_data['jenis_kelamin'] ?></td>
                            <td><?php echo $user_data['no_telepon'] ?></td>
                            <td><?php echo $user_data['alamat'] ?></td>
                            <td>
                                <a href="update_siswa.php?id=<?php echo $user_data['id'] ?>" class="btn btn-sm btn-warning">EDIT</a>
                                <a href="hapus_siswa.php?id=<?php echo $user_data['id'] ?>" onclick="return confirm('anda yakin ingin hapus?');" class="btn btn-sm btn-danger">HAPUS</a>
                            </td>
                        </tr>
                        <?php 
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>