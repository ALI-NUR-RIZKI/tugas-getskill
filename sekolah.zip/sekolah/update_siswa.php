<html>
<head>
    <title>Edit Siswa</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>
</head>
<body class="bg-light">
<?php
    include("koneksi.php");
    $id = $_GET['id'];
    $query_mysqli = mysqli_query($mysqli, "SELECT * FROM siswa WHERE id='$id'") or die(mysqli_error($mysqli));
    $nomor = 1;
    while($data = mysqli_fetch_array($query_mysqli)){
?>
<div class="container bg-light col-md-6 mt-4">
    <div class="card bg-light">
        <div class="card-body">
            <form action="action_update.php" method="post" role="form">
                <div class="form-group">
                    <label>No Induk</label>
                    <input type="hidden" name="id" value="<?php echo $data['id'] ?>">
                    <input type="text" name="no_induk" value="<?php echo $data['no_induk'] ?>" class="form-control">
                </div>
                <div class="form-group">
                    <label>Nama</label>
                    <input type="text" name="nama" value="<?php echo $data['nama'] ?>" class="form-control">
                </div>
                <div class="form-group">
                    <label>Jenis kelamin</label>
                    <select name="jenis_kelamin" class="form-control">
                        <option value="<?php echo $data['jenis_kelamin'] ?>"><?php echo $data['jenis_kelamin'] ?></option>
                        <option value="Laki-laki">Laki-laki</option>
                        <option value="Perempuan">Perempuan</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>No Telepon</label>
                    <input type="text" name="no_telepon" value="<?php echo $data['no_telepon'] ?>" class="form-control">
                </div>
                <div class="form-group">
                    <label>Alamat</label>
                    <input type="text" name="alamat" value="<?php echo $data['alamat'] ?>" class="form-control">
                </div>

                <button type="submit" class="btn btn-primary" name="submit" value="simpan">Update</button>
            </form>
            <?php } ?>
        </div>
    </div>
</div>
</body>
</html>