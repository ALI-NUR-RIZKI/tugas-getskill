<?php
include ('koneksi.php');

$id = $_POST['id'];
$no_induk = $_POST['no_induk'];
$nama = $_POST['nama'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$no_telepon = $_POST['no_telepon'];
$alamat = $_POST['alamat'];

$result = mysqli_query($mysqli, "UPDATE siswa SET no_induk='$no_induk',nama='$nama',jenis_kelamin='$jenis_kelamin',no_telepon='$no_telepon',alamat='$alamat' WHERE id=$id");

echo "<script>alert('data berhasil diperbarui.');window.location='index_siswa.php';</script>";

?>