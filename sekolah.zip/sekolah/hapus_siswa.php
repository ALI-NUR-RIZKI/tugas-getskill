<?php
    include_once("koneksi.php");
    $id = $_GET['id'];
    $result = mysqli_query($mysqli, "DELETE FROM siswa WHERE id=$id");

    echo "<script>alert('data berhasil dihapus.');window.location='index_siswa.php';</script>";
?>