<?php
  include ("koneksi.php");
  if(isset($_POST['Submit'])) {
      $id = $_POST['id'];
      $no_induk = $_POST['no_induk'];
      $nama = $_POST['nama'];
      $jenis_kelamin = $_POST['jenis_kelamin'];
      $no_telepon = $_POST['no_telepon'];
      $alamat = $_POST['alamat'];

      $result = mysqli_query($mysqli, "INSERT INTO siswa(id,no_induk,nama,jenis_kelamin,no_telepon,alamat) VALUES('$id','$no_induk','$nama','$jenis_kelamin','$no_telepon','$alamat')");

      echo "<script>alert('data berhasil disimpan.');window.location='index_siswa.php';</script>";

  }
?>