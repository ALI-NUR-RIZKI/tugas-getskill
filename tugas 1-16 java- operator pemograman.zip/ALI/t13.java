import java.util.Scanner;

public class t13 {
    public static void main(String[] args) {
        // Membuat objek Scanner untuk membaca input dari pengguna
        Scanner input = new Scanner(System.in);

        // Menampilkan soal kuis dan pilihan jawaban
        System.out.println("=== KUIS PEMROGRAMAN JAVA ===");
        System.out.println("Soal: Berikut ini manakah yang termasuk jenis operator di dalam pemrograman Java?");
        System.out.println("A. Operator Indosat");
        System.out.println("B. Operator Aritmatika");
        System.out.println("C. Operator Telkomsel");
        System.out.println("D. Operator Assignment");
        System.out.println("----------------------------------------");

        // Meminta input jawaban dari pengguna
        System.out.print("Pilih jawaban Anda (A/B/C/D): ");
        String jawaban = input.nextLine().trim().toUpperCase();

        // Menggunakan operator logika OR (||) untuk memvalidasi jawaban benar (B atau D)
        boolean isBenar = jawaban.equals("B") || jawaban.equals("D");

        // Menampilkan hasil evaluasi jawaban
        System.out.println("----------------------------------------");
        if (isBenar) {
            System.out.println("Jawaban Anda BENAR!");
            System.out.println("Poin yang didapatkan: 1");
        } else {
            System.out.println("Jawaban Anda SALAH!");
            System.out.println("Poin yang didapatkan: 0");
        }

        // Menutup objek Scanner
        input.close();
    }
}