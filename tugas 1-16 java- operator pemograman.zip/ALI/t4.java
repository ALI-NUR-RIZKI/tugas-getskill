public class t4 {
    public static void main(String[] args) {
        // Deklarasi nilai ketiga siswa
        double nilai1 = 80;
        double nilai2 = 95;
        double nilai3 = 75;

        // Inisialisasi variabel untuk total nilai
        double total = 0;

        // Menerapkan operator assignment penjumlahan (+=) untuk menghitung total
        total += nilai1;
        total += nilai2;
        total += nilai3;

        // Mempersiapkan variabel untuk rata-rata
        double rataRata = total;

        // Menerapkan operator assignment pembagian (/=) untuk menghitung rata-rata (dibagi 3 siswa)
        rataRata /= 3;

        // Menampilkan hasil
        System.out.println("=== HASIL PERHITUNGAN NILAI SISWA ===");
        System.out.println("Nilai Siswa 1 : " + nilai1);
        System.out.println("Nilai Siswa 2 : " + nilai2);
        System.out.println("Nilai Siswa 3 : " + nilai3);
        System.out.println("-------------------------------------");
        System.out.println("Total Nilai   : " + total);
        System.out.println("Rata-rata     : " + rataRata);
    }
}