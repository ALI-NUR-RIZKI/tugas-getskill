import java.util.Scanner;

public class t1 {
    public static void main(String[] args) {
        // Membuat objek Scanner untuk membaca input dari user
        Scanner input = new Scanner(System.in);

        System.out.println("=== PROGRAM MENGHITUNG LUAS SEGITIGA ===");

        // Meminta input nilai alas
        System.out.print("Masukkan nilai alas (cm): ");
        double alas = input.nextDouble();

        // Meminta input nilai tinggi
        System.out.print("Masukkan nilai tinggi (cm): ");
        double tinggi = input.nextDouble();

        // Menghitung luas segitiga (Rumus: 0.5 * alas * tinggi)
        double luas = 0.5 * alas * tinggi;

        // Menampilkan hasil perhitungan
        System.out.println("----------------------------------------");
        System.out.println("Luas Segitiga adalah: " + luas + " cm²");

        // Menutup objek Scanner
        input.close();
    }
}