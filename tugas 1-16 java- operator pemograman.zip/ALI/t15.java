import java.util.Scanner;

public class t15 {
    public static void main(String[] args) {
        // Membuat objek Scanner untuk mengambil input dari user
        Scanner input = new Scanner(System.in);

        System.out.println("=== PROGRAM OPERATOR BITWISE SHIFT ===");

        // Meminta input nilai a
        System.out.print("Masukkan nilai a: ");
        int a = input.nextInt();

        // Meminta input nilai b
        System.out.print("Masukkan nilai b: ");
        int b = input.nextInt();

        // Operasi Left Shift (a << 2)
        int leftShift = a << 2;

        // Operasi Right Shift (b >> 2)
        int rightShift = b >> 2;

        // Menampilkan hasil pergeseran bit
        System.out.println("-------------------------------------");
        System.out.println("Hasil Left Shift  (a << 2) : " + leftShift);
        System.out.println("Hasil Right Shift (b >> 2) : " + rightShift);

        // Menutup objek Scanner
        input.close();
    }
}