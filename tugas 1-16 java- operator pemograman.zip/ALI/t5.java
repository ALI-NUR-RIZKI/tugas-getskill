import javax.swing.JOptionPane;

public class t5 {
    public static void main(String[] args) {
        // Jumlah awal stok barang di minimarket
        int sirup = 5;
        int deterjen = 6;
        int mieInstan = 10;

        // Tampilkan stok awal ke pengguna
        String infoAwal = "=== STOK AWAL MINIMARKET ===\n"
                        + "1. Sirup: " + sirup + " botol\n"
                        + "2. Deterjen: " + deterjen + " bungkus\n"
                        + "3. Mie Instan: " + mieInstan + " bungkus";
        JOptionPane.showMessageDialog(null, infoAwal, "Stok Awal", JOptionPane.INFORMATION_MESSAGE);

        // Input tambahan barang dari distributor menggunakan JOptionPane
        String inputSirup = JOptionPane.showInputDialog(null, "Masukkan tambahan stok Sirup dari distributor:");
        String inputDeterjen = JOptionPane.showInputDialog(null, "Masukkan tambahan stok Deterjen dari distributor:");
        String inputMie = JOptionPane.showInputDialog(null, "Masukkan tambahan stok Mie Instan dari distributor:");

        // Konversi input String dari JOptionPane menjadi Integer
        int tambahSirup = Integer.parseInt(inputSirup);
        int tambahDeterjen = Integer.parseInt(inputDeterjen);
        int tambahMie = Integer.parseInt(inputMie);

        // Menggunakan OPERATOR ASSIGNMENT (+=) untuk mengupdate jumlah stok
        sirup += tambahSirup;
        deterjen += tambahDeterjen;
        mieInstan += tambahMie;

        // Menampilkan stok akhir setelah penambahan
        String infoAkhir = "=== STOK AKHIR MINIMARKET ===\n"
                         + "1. Sirup: " + sirup + " botol (Tambah " + tambahSirup + ")\n"
                         + "2. Deterjen: " + deterjen + " bungkus (Tambah " + tambahDeterjen + ")\n"
                         + "3. Mie Instan: " + mieInstan + " bungkus (Tambah " + tambahMie + ")";
        
        JOptionPane.showMessageDialog(null, infoAkhir, "Stok Terbaru", JOptionPane.INFORMATION_MESSAGE);
    }
}