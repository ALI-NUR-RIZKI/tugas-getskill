import java.util.Scanner;

public class t12 {
    public static void main(String[] args) {
        // Membuat objek Scanner untuk membaca input dari user
        Scanner input = new Scanner(System.in);

        System.out.println("=== PROGRAM SELEKSI PEGAWAI ===");

        // Input tinggi badan
        System.out.print("Masukkan Tinggi Badan (cm): ");
        int tinggi = input.nextInt();

        // Input nilai UN
        System.out.print("Masukkan Nilai UN: ");
        double nilaiUN = input.nextDouble();

        // Pengecekan syarat: tinggi minimal 160 DAN nilai UN minimal 80
        boolean lulus = (tinggi >= 160) && (nilaiUN >= 80);

        // Menampilkan hasil kualifikasi (true / false)
        System.out.println("--------------------------------");
        System.out.println("Memenuhi Syarat (true/false) : " + lulus);

        // Menutup Scanner
        input.close();
    }
}