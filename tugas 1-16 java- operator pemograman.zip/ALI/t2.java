import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class t2 {
    public static void main(String[] args) {
        // Membuat objek BufferedReader untuk membaca input dari keyboard
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        try {
            System.out.println("=== PROGRAM MENGHITUNG RUMUS: a + b * c ===");

            // Meminta input nilai a
            System.out.print("Masukkan nilai a: ");
            double a = Double.parseDouble(reader.readLine());

            // Meminta input nilai b
            System.out.print("Masukkan nilai b: ");
            double b = Double.parseDouble(reader.readLine());

            // Meminta input nilai c
            System.out.print("Masukkan nilai c: ");
            double c = Double.parseDouble(reader.readLine());

            // Menhitung rumus a + b * c
            // Perkalian (b * c) akan dieksekusi terlebih dahulu sesuai presedensi operator
            double hasil = a + b * c;

            // Menampilkan hasil perhitungan
            System.out.println("-------------------------------------------");
            System.out.println("Hasil dari " + a + " + " + b + " * " + c + " = " + hasil);

        } catch (IOException e) {
            System.out.println("Terjadi kesalahan saat membaca input: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Input yang dimasukkan harus berupa angka!");
        }
    }
}