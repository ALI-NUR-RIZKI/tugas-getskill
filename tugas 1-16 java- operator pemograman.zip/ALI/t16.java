import java.util.Scanner;

public class t16 {
    public static void main(String[] args) {
        // Membuat objek Scanner untuk membaca input dari pengguna
        Scanner input = new Scanner(System.in);

        System.out.println("Jawab pertanyaan dengan memasukkan (ya) atau (tidak)");

        // Pertanyaan 1: Nilai Akademik
        System.out.println("Apakah nilai akademik kamu lebih dari 70?");
        String inputNilai = input.nextLine().trim();

        // Pertanyaan 2: Ketidakhadiran
        System.out.println("Apakah ketidakhadiran kamu selama 1 semester kurang dari 10?");
        String inputAbsen = input.nextLine().trim();

        // Memeriksa jawaban menggunakan operator ternary
        boolean isNilaiBaguis = inputNilai.equalsIgnoreCase("ya");
        boolean isAbsenBagus = inputAbsen.equalsIgnoreCase("ya");

        // Operator Ternary untuk menentukan pesan kenaikan kelas
        String statusNaik = (isNilaiBaguis && isAbsenBagus) 
                ? "Selamat kamu naik kelas... :)" 
                : "Maaf, kamu tidak naik kelas";

        // Operator Ternary untuk menentukan saran motivasi
        String pesanMotivasi = (isNilaiBaguis || isAbsenBagus) 
                ? "Pertahankan nilaimu" 
                : "Semangat belajar lagi";

        // Menampilkan output
        System.out.println(statusNaik);
        System.out.println(pesanMotivasi);

        // Menutup objek Scanner
        input.close();
    }
}