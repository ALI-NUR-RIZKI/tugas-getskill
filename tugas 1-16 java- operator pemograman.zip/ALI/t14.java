import java.util.Scanner;

public class t14 {
    public static void main(String[] args) {
        // Membuat objek Scanner untuk membaca input dari user
        Scanner input = new Scanner(System.in);

        System.out.println("=== PROGRAM PENGECEKAN KELULUSAN SISWA ===");
        
        // Meminta input NIS dari user
        System.out.print("Masukkan NIS: ");
        int nis = input.nextInt();

        // Mengecek apakah NIS termasuk data siswa yang lulus (1001, 1002, 1003, atau 1004)
        boolean statusLulus = (nis == 1001) || (nis == 1002) || (nis == 1003) || (nis == 1004);

        // Menampilkan hasil pengecekan (true / false)
        System.out.println("------------------------------------------");
        System.out.println("Status Lulus (true/false) : " + statusLulus);

        // Menutup Scanner
        input.close();
    }
}