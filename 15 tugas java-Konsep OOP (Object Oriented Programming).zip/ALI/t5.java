import javax.swing.JOptionPane;

// Class Karakter Kura-Kura (Tamagotchi)
class KuraKura {
    // Properti (Atribut)
    private int kesehatan;
    private int kekuatan;
    private int pengalaman;

    // Konstruktor Nilai Awal
    public KuraKura(int kesehatanAwal, int kekuatanAwal, int pengalamanAwal) {
        this.kesehatan = kesehatanAwal;
        this.kekuatan = kekuatanAwal;
        this.pengalaman = pengalamanAwal;
    }

    // Behaviour: Makan (Kesehatan +2, Kekuatan +3, Pengalaman +0)
    public void makan() {
        this.kesehatan += 2;
        this.kekuatan += 3;
        JOptionPane.showMessageDialog(null, "Kura-kura sedang makan!\nKesehatan +2, Kekuatan +3");
    }

    // Behaviour: Minum (Kesehatan +1, Kekuatan +1, Pengalaman +0)
    public void minum() {
        this.kesehatan += 1;
        this.kekuatan += 1;
        JOptionPane.showMessageDialog(null, "Kura-kura sedang minum!\nKesehatan +1, Kekuatan +1");
    }

    // Behaviour: Berjalan (Kesehatan -1, Kekuatan -1, Pengalaman +2)
    public void berjalan() {
        this.kesehatan -= 1;
        this.kekuatan -= 1;
        this.pengalaman += 2;
        JOptionPane.showMessageDialog(null, "Kura-kura sedang berjalan!\nKesehatan -1, Kekuatan -1, Pengalaman +2");
    }

    // Behaviour: Bertarung (Kesehatan -2, Kekuatan -3, Pengalaman +3)
    public void bertarung() {
        this.kesehatan -= 2;
        this.kekuatan -= 3;
        this.pengalaman += 3;
        JOptionPane.showMessageDialog(null, "Kura-kura sedang bertarung!\nKesehatan -2, Kekuatan -3, Pengalaman +3");
    }

    // Method untuk menampilkan status karakter
    public String getStatus() {
        return "=== STATUS KURA-KURA ===\n" +
               "Kesehatan  : " + kesehatan + "\n" +
               "Kekuatan   : " + kekuatan + "\n" +
               "Pengalaman : " + pengalaman;
    }
}

// Class Main (Program Utama)
public class t5 {
    public static void main(String[] args) {
        // Objek Kura-kura dengan nilai status awal
        KuraKura tamagotchi = new KuraKura(10, 10, 0);

        boolean running = true;

        while (running) {
            // Menampilkan Menu Pilihan dengan JOptionPane
            String menu = tamagotchi.getStatus() + "\n\n" +
                    "Pilih Tindakan:\n" +
                    "1. Makan\n" +
                    "2. Minum\n" +
                    "3. Berjalan\n" +
                    "4. Bertarung\n" +
                    "5. Keluar\n\n" +
                    "Masukkan nomor opsi (1-5):";

            String input = JOptionPane.showInputDialog(null, menu, "Tamagotchi Game", JOptionPane.QUESTION_MESSAGE);

            if (input == null || input.equals("5")) {
                JOptionPane.showMessageDialog(null, "Terima kasih telah bermain!");
                running = false;
            } else {
                switch (input) {
                    case "1":
                        tamagotchi.makan();
                        break;
                    case "2":
                        tamagotchi.minum();
                        break;
                    case "3":
                        tamagotchi.berjalan();
                        break;
                    case "4":
                        tamagotchi.bertarung();
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Pilihan tidak valid, silakan coba lagi.");
                }
            }
        }
    }
}