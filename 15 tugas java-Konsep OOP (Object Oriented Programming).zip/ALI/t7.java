import java.util.Scanner;

// Superclass (Parent Class)
class BangunRuang {
    // Method dasar volume (di-override oleh subclass)
    public double volume() {
        return 0;
    }
}

// Subclass 1: Balok
class Balok extends BangunRuang {
    private double panjang;
    private double lebar;
    private double tinggi;

    // Setter & Getter
    public void setPanjang(double panjang) {
        this.panjang = panjang;
    }

    public double getPanjang() {
        return panjang;
    }

    public void setLebar(double lebar) {
        this.lebar = lebar;
    }

    public double getLebar() {
        return lebar;
    }

    public void setTinggi(double tinggi) {
        this.tinggi = tinggi;
    }

    public double getTinggi() {
        return tinggi;
    }

    // Overriding Method Volume
    @Override
    public double volume() {
        return panjang * lebar * tinggi;
    }
}

// Subclass 2: Kubus
class Kubus extends BangunRuang {
    private double sisi;

    // Setter & Getter
    public void setSisi(double sisi) {
        this.sisi = sisi;
    }

    public double getSisi() {
        return sisi;
    }

    // Overriding Method Volume
    @Override
    public double volume() {
        return sisi * sisi * sisi;
    }
}

// Subclass 3: Tabung
class Tabung extends BangunRuang {
    private double r;
    private double tinggi;

    // Setter & Getter
    public void setR(double r) {
        this.r = r;
    }

    public double getR() {
        return r;
    }

    public void setTinggi(double tinggi) {
        this.tinggi = tinggi;
    }

    public double getTinggi() {
        return tinggi;
    }

    // Overriding Method Volume
    @Override
    public double volume() {
        return Math.PI * r * r * tinggi;
    }
}

// Subclass 4: Kerucut
class Kerucut extends BangunRuang {
    private double r;
    private double tinggi;

    // Setter & Getter
    public void setR(double r) {
        this.r = r;
    }

    public double getR() {
        return r;
    }

    public void setTinggi(double tinggi) {
        this.tinggi = tinggi;
    }

    public double getTinggi() {
        return tinggi;
    }

    // Overriding Method Volume
    @Override
    public double volume() {
        return (1.0 / 3.0) * Math.PI * r * r * tinggi;
    }
}

// Class Main (Program Utama)
public class t7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean berjalan = true;

        while (berjalan) {
            System.out.println("\n=== MENU HITUNG VOLUME BANGUN RUANG ===");
            System.out.println("1. Balok");
            System.out.println("2. Kubus");
            System.out.println("3. Tabung");
            System.out.println("4. Kerucut");
            System.out.println("5. Selesai");
            System.out.print("Pilih menu (1-5): ");

            int pilihan = scanner.nextInt();

            switch (pilihan) {
                case 1:
                    Balok balok = new Balok();
                    System.out.print("Masukkan panjang: ");
                    balok.setPanjang(scanner.nextDouble());
                    System.out.print("Masukkan lebar: ");
                    balok.setLebar(scanner.nextDouble());
                    System.out.print("Masukkan tinggi: ");
                    balok.setTinggi(scanner.nextDouble());

                    System.out.println("---------------------------------------");
                    System.out.println("Data Balok (Panjang: " + balok.getPanjang() + ", Lebar: " + balok.getLebar() + ", Tinggi: " + balok.getTinggi() + ")");
                    System.out.printf("Volume Balok = %.2f%n", balok.volume());
                    break;

                case 2:
                    Kubus kubus = new Kubus();
                    System.out.print("Masukkan panjang sisi: ");
                    kubus.setSisi(scanner.nextDouble());

                    System.out.println("---------------------------------------");
                    System.out.println("Data Kubus (Sisi: " + kubus.getSisi() + ")");
                    System.out.printf("Volume Kubus = %.2f%n", kubus.volume());
                    break;

                case 3:
                    Tabung tabung = new Tabung();
                    System.out.print("Masukkan jari-jari (r): ");
                    tabung.setR(scanner.nextDouble());
                    System.out.print("Masukkan tinggi: ");
                    tabung.setTinggi(scanner.nextDouble());

                    System.out.println("---------------------------------------");
                    System.out.println("Data Tabung (r: " + tabung.getR() + ", Tinggi: " + tabung.getTinggi() + ")");
                    System.out.printf("Volume Tabung = %.2f%n", tabung.volume());
                    break;

                case 4:
                    Kerucut kerucut = new Kerucut();
                    System.out.print("Masukkan jari-jari (r): ");
                    kerucut.setR(scanner.nextDouble());
                    System.out.print("Masukkan tinggi: ");
                    kerucut.setTinggi(scanner.nextDouble());

                    System.out.println("---------------------------------------");
                    System.out.println("Data Kerucut (r: " + kerucut.getR() + ", Tinggi: " + kerucut.getTinggi() + ")");
                    System.out.printf("Volume Kerucut = %.2f%n", kerucut.volume());
                    break;

                case 5:
                    System.out.println("Program selesai. Terima kasih!");
                    berjalan = false;
                    break;

                default:
                    System.out.println("Pilihan tidak valid! Silakan masukkan angka 1-5.");
            }
        }

        scanner.close();
    }
}