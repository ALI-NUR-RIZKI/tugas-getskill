import java.util.Scanner;

// Abstract Superclass Binatang
abstract class Binatang {
    // Abstract Methods (wajib di-override oleh kelas turunan)
    public abstract void makan();
    public abstract void berkembangbiak();
    public abstract void hidupdi();
    public abstract void termasukjenishewan();
}

// Subclass Gajah
class Gajah extends Binatang {
    @Override
    public void makan() {
        System.out.println("makan rumput");
    }

    @Override
    public void berkembangbiak() {
        System.out.println("berkembang biak dengan beranak");
    }

    @Override
    public void hidupdi() {
        System.out.println("hidup di darat");
    }

    @Override
    public void termasukjenishewan() {
        System.out.println("termasuk binatang herbivora");
    }
}

// Subclass Kelinci
class Kelinci extends Binatang {
    @Override
    public void makan() {
        System.out.println("makan wortel dan sayuran");
    }

    @Override
    public void berkembangbiak() {
        System.out.println("berkembang biak dengan beranak");
    }

    @Override
    public void hidupdi() {
        System.out.println("hidup di darat");
    }

    @Override
    public void termasukjenishewan() {
        System.out.println("termasuk binatang herbivora");
    }
}

// Subclass Burung
class Burung extends Binatang {
    @Override
    public void makan() {
        System.out.println("makan biji-bijian");
    }

    @Override
    public void berkembangbiak() {
        System.out.println("berkembang biak dengan bertelur");
    }

    @Override
    public void hidupdi() {
        System.out.println("hidup di udara dan pohon");
    }

    @Override
    public void termasukjenishewan() {
        System.out.println("termasuk binatang aves");
    }
}

// Subclass Kucing
class Kucing extends Binatang {
    @Override
    public void makan() {
        System.out.println("makan daging dan ikan");
    }

    @Override
    public void berkembangbiak() {
        System.out.println("berkembang biak dengan beranak");
    }

    @Override
    public void hidupdi() {
        System.out.println("hidup di darat");
    }

    @Override
    public void termasukjenishewan() {
        System.out.println("termasuk binatang karnivora");
    }
}

// Main Class
public class t13 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        boolean berjalan = true;

        while (berjalan) {
            System.out.println("\n*** Kebon Binatang Surabaya ***");
            System.out.println("1. Gajah");
            System.out.println("2. Kelinci");
            System.out.println("3. Burung");
            System.out.println("4. Kucing");
            System.out.println("5. keluar");
            System.out.print("Masukkan pilihan : ");

            int pilihan = input.nextInt();

            // Referensi bertipe Abstract Class (Binatang)
            Binatang hewan = null;

            switch (pilihan) {
                case 1:
                    hewan = new Gajah();
                    System.out.println("--- info gajah madagaskar ---");
                    break;
                case 2:
                    hewan = new Kelinci();
                    System.out.println("--- info kelinci ---");
                    break;
                case 3:
                    hewan = new Burung();
                    System.out.println("--- info burung ---");
                    break;
                case 4:
                    hewan = new Kucing();
                    System.out.println("--- info kucing ---");
                    break;
                case 5:
                    System.out.println("Program selesai. Terima kasih!");
                    berjalan = false;
                    continue;
                default:
                    System.out.println("Pilihan tidak valid, silakan coba lagi!");
                    continue;
            }

            // Memanggil implementation method dari abstract class
            if (hewan != null) {
                hewan.makan();
                hewan.berkembangbiak();
                hewan.hidupdi();
                hewan.termasukjenishewan();
                System.out.println("----------------------------------------");
            }
        }

        input.close();
    }
}