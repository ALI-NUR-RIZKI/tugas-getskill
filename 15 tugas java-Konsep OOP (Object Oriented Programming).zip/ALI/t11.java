import java.util.Scanner;

// Superclass Karyawan
class Karyawan {
    private String nama;
    private double gaji;
    private double persenNaikGaji = 0.10; // 10%

    // Konstruktor
    public Karyawan(String nama, double gaji) {
        this.nama = nama;
        this.gaji = gaji;
    }

    // Getter untuk nama
    public String getNama() {
        return nama;
    }

    // Getter untuk gaji dasar
    public double getGaji() {
        return gaji;
    }

    // Getter untuk persen kenaikan gaji
    public double getPersenNaikGaji() {
        return persenNaikGaji;
    }

    // Method untuk menampilkan informasi karyawan
    public void tampilkanInfo() {
        System.out.println("Nama Karyawan : " + nama);
        System.out.printf("Gaji Pokok    : Rp %,.2f%n", gaji);
    }
}

// Subclass Manager (Turunan dari Karyawan)
class Manager extends Karyawan {

    // Konstruktor Manager
    public Manager(String nama, double gaji) {
        super(nama, gaji);
    }

    // Overriding Method getGaji() untuk menghitung kenaikan gaji 10%
    @Override
    public double getGaji() {
        double gajiAwal = super.getGaji();
        double kenaikan = gajiAwal * getPersenNaikGaji();
        return gajiAwal + kenaikan;
    }

    // Method tambahan untuk menampilkan info lengkap Manager
    @Override
    public void tampilkanInfo() {
        System.out.println("Nama Manager   : " + getNama());
        System.out.printf("Gaji Awal      : Rp %,.2f%n", super.getGaji());
        System.out.printf("Kenaikan (10%%) : Rp %,.2f%n", super.getGaji() * getPersenNaikGaji());
        System.out.printf("Gaji Akhir     : Rp %,.2f%n", getGaji());
    }
}

// Main Class
public class t11 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== PROGRAM HITUNG KENAIKAN GAJI MANAGER ===");
        System.out.print("Masukkan Nama Manager : ");
        String nama = scanner.nextLine();

        System.out.print("Masukkan Gaji Pokok   : Rp ");
        double gaji = scanner.nextDouble();

        System.out.println("\n-------------------------------------------");

        // Konsep Polymorphism: Acuan Superclass (Karyawan) menampung objek Subclass (Manager)
        Karyawan manager = new Manager(nama, gaji);

        // Menampilkan Informasi
        manager.tampilkanInfo();

        System.out.println("-------------------------------------------");
        scanner.close();
    }
}