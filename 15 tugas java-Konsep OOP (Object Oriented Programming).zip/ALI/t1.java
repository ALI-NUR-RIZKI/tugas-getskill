class t1 {
    // Atribut (private modifier)
    private int id;
    private String judul;
    private int jumlah;

    // Method untuk menampilkan data/informasi t1
    public void tampilkanData() {
        System.out.println("ID = " + id + ", Judul = \"" + judul + "\", Jumlah = " + jumlah);
    }

    // Setter untuk mengisi atribut
    public void sett1(int id, String judul, int jumlah) {
        this.id = id;
        this.judul = judul;
        this.jumlah = jumlah;
    }
}

class Main {
    public static void main(String[] args) {
        // Membuat object dari class t1
        t1 t11 = new t1();

        // Mengisi nilai atribut sesuai instruksi soal
        t11.sett1(101, "Habis Gelap Terbitlah Terang", 10);

        // Menampilkan data t1
        t11.tampilkanData();
    }
}