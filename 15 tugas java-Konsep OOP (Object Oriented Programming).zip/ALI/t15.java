import java.util.Scanner;

// Interface Control
interface Control {
    void pindahChanel(int index);
    void perbesarVolume(int vol);
    void perkecilVolume(int vol);
}

// Class Samsung mengimplementasikan Interface Control
class Samsung implements Control {
    private String namaTv = "TV Samsung";
    private String[] channels = {"RCTI", "MNCTV", "GTV", "iNews", "TRANS7", "SCTV", "Indosiar", "NET TV"};

    @Override
    public void pindahChanel(int index) {
        if (index >= 0 && index < channels.length) {
            System.out.println(namaTv + " pindah chanel ke : " + channels[index]);
        } else {
            System.out.println("Chanel tidak ditemukan! Masukkan indeks (0 - " + (channels.length - 1) + ")");
        }
    }

    @Override
    public void perbesarVolume(int vol) {
        System.out.println(namaTv + " perbesar volume ke : " + vol);
    }

    @Override
    public void perkecilVolume(int vol) {
        System.out.println(namaTv + " perkecil volume ke : " + vol);
    }
}

// Class Polytron mengimplementasikan Interface Control
class Polytron implements Control {
    private String namaTv = "TV Polytron";
    private String[] channels = {"RCTI", "MNCTV", "GTV", "iNews", "TRANS7", "SCTV", "Indosiar", "NET TV"};

    @Override
    public void pindahChanel(int index) {
        if (index >= 0 && index < channels.length) {
            System.out.println(namaTv + " pindah chanel ke : " + channels[index]);
        } else {
            System.out.println("Chanel tidak ditemukan! Masukkan indeks (0 - " + (channels.length - 1) + ")");
        }
    }

    @Override
    public void perbesarVolume(int vol) {
        System.out.println(namaTv + " perbesar volume ke : " + vol);
    }

    @Override
    public void perkecilVolume(int vol) {
        System.out.println(namaTv + " perkecil volume ke : " + vol);
    }
}

// Class RemoteControl untuk mengatur aksi perangkat TV
class RemoteControl {
    private Control tv;

    public void setTv(Control tv) {
        this.tv = tv;
    }

    public void pindahChanel(int index) {
        if (tv != null) {
            tv.pindahChanel(index);
        }
    }

    public void perbesarVolume(int vol) {
        if (tv != null) {
            tv.perbesarVolume(vol);
        }
    }

    public void perkecilVolume(int vol) {
        if (tv != null) {
            tv.perkecilVolume(vol);
        }
    }
}

// Main Class
public class t15 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RemoteControl remote = new RemoteControl();

        System.out.println("Menu :");
        System.out.println("1. Pindah Chanel");
        System.out.println("2. Perbesar Volume");
        System.out.println("3. Perkecil Volume");
        int menu = scanner.nextInt();

        System.out.println("Pilih TV :");
        System.out.println("1. Samsung");
        System.out.println("2. Polytron");
        int pilihTv = scanner.nextInt();

        // Menentukan objek TV berdasarkan input
        if (pilihTv == 1) {
            remote.setTv(new Samsung());
        } else if (pilihTv == 2) {
            remote.setTv(new Polytron());
        } else {
            System.out.println("Pilihan TV tidak valid!");
            scanner.close();
            return;
        }

        // Eksekusi aksi berdasarkan menu yang dipilih
        switch (menu) {
            case 1:
                System.out.println("Masukkan Chanel/Volume [0 - 7]");
                int chanel = scanner.nextInt();
                remote.pindahChanel(chanel);
                break;
            case 2:
                System.out.println("Masukkan Nilai Volume:");
                int volBesar = scanner.nextInt();
                remote.perbesarVolume(volBesar);
                break;
            case 3:
                System.out.println("Masukkan Nilai Volume:");
                int volKecil = scanner.nextInt();
                remote.perkecilVolume(volKecil);
                break;
            default:
                System.out.println("Menu tidak valid!");
        }

        scanner.close();
    }
}