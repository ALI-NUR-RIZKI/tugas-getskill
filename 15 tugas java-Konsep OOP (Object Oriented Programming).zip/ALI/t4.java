class User {
    // Atribut private untuk enkapsulasi
    private String username;
    private String password;

    // Method Setter untuk Username
    public void setUsername(String username) {
        this.username = username;
    }

    // Method Getter untuk Username
    public String getUsername() {
        return username;
    }

    // Method Setter untuk Password
    public void setPassword(String password) {
        this.password = password;
    }

    // Method Getter untuk Password
    public String getPassword() {
        return password;
    }

    // Method untuk memeriksa apakah panjang password tepat 8 karakter
    public boolean isPasswordValid() {
        return password != null && password.length() == 8;
    }

    // Method untuk menampilkan data user dan status kesesuaian
    public void tampilkanInfo() {
        System.out.println("Username: " + username);
        System.out.println("Password: " + password);

        if (isPasswordValid()) {
            System.out.println("Username & Password Sesuai");
        } else {
            System.out.println("Username & Password Tidak Sesuai");
        }
    }
}

// Class Main (Program Utama)
public class t4 {
    public static void main(String[] args) {
        // Contoh 1: Password 8 karakter ("kopiJava") -> Sesuai
        User user1 = new User();
        user1.setUsername("mr.x");
        user1.setPassword("kopiJava");
        user1.tampilkanInfo();

        System.out.println("--------------------------------");

        // Contoh 2: Password kurang dari 8 karakter ("kopiku") -> Tidak Sesuai
        User user2 = new User();
        user2.setUsername("mr.x");
        user2.setPassword("kopiku");
        user2.tampilkanInfo();
    }
}