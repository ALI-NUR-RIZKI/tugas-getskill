import java.util.Scanner;

// Superclass (Parent Class)
class BangunDatar {
    public float luas() {
        return 0;
    }

    public float keliling() {
        return 0;
    }
}

// Subclass 1: Persegi Panjang
class PersegiPanjang extends BangunDatar {
    float panjang;
    float lebar;

    @Override
    public float luas() {
        return panjang * lebar;
    }

    @Override
    public float keliling() {
        return 2 * (panjang + lebar);
    }
}

// Subclass 2: Persegi
class Persegi extends BangunDatar {
    float sisi;

    @Override
    public float luas() {
        return sisi * sisi;
    }

    @Override
    public float keliling() {
        return 4 * sisi;
    }
}

// Subclass 3: Segitiga (Asumsi Segitiga Siku-Siku / Sama Sisi untuk keliling)
class Segitiga extends BangunDatar {
    float alas;
    float tinggi;

    @Override
    public float luas() {
        return 0.5f * alas * tinggi;
    }

    @Override
    public float keliling() {
        // Menghitung sisi miring dengan rumus Phytagoras
        float sisiMiring = (float) Math.sqrt((alas * alas) + (tinggi * tinggi));
        return alas + tinggi + sisiMiring;
    }
}

// Subclass 4: Lingkaran
class Lingkaran extends BangunDatar {
    float r;

    @Override
    public float luas() {
        return (float) (Math.PI * r * r);
    }

    @Override
    public float keliling() {
        return (float) (2 * Math.PI * r);
    }
}

// Class Main (Program Utama)
public class t6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean berjalan = true;

        while (berjalan) {
            System.out.println("\n=== MENU HITUNG BANGUN DATAR ===");
            System.out.println("1. Persegi Panjang");
            System.out.println("2. Persegi");
            System.out.println("3. Segitiga");
            System.out.println("4. Lingkaran");
            System.out.println("5. Selesai");
            System.out.print("Pilih menu (1-5): ");

            int pilihan = scanner.nextInt();

            switch (pilihan) {
                case 1:
                    PersegiPanjang pp = new PersegiPanjang();
                    System.out.print("Masukkan panjang: ");
                    pp.panjang = scanner.nextFloat();
                    System.out.print("Masukkan lebar: ");
                    pp.lebar = scanner.nextFloat();

                    System.out.println("Luas Persegi Panjang: " + pp.luas());
                    System.out.println("Keliling Persegi Panjang: " + pp.keliling());
                    break;

                case 2:
                    Persegi p = new Persegi();
                    System.out.print("Masukkan sisi: ");
                    p.sisi = scanner.nextFloat();

                    System.out.println("Luas Persegi: " + p.luas());
                    System.out.println("Keliling Persegi: " + p.keliling());
                    break;

                case 3:
                    Segitiga s = new Segitiga();
                    System.out.print("Masukkan alas: ");
                    s.alas = scanner.nextFloat();
                    System.out.print("Masukkan tinggi: ");
                    s.tinggi = scanner.nextFloat();

                    System.out.println("Luas Segitiga: " + s.luas());
                    System.out.println("Keliling Segitiga: " + s.keliling());
                    break;

                case 4:
                    Lingkaran l = new Lingkaran();
                    System.out.print("Masukkan jari-jari (r): ");
                    l.r = scanner.nextFloat();

                    System.out.println("Luas Lingkaran: " + l.luas());
                    System.out.println("Keliling Lingkaran: " + l.keliling());
                    break;

                case 5:
                    System.out.println("Program selesai. Terima kasih!");
                    berjalan = false;
                    break;

                default:
                    System.out.println("Pilihan tidak valid! Silakan masukkan angka 1-5.");
            }
        }

        scanner.close();
    }
}