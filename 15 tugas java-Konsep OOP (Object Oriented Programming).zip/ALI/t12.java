import java.util.Scanner;

// Superclass Timbangan
class Timbangan {
    protected int jenisKelamin; // 0: Perempuan, 1: Laki-laki
    protected double tinggi;

    public void setJenisKelamin(int jenisKelamin) {
        this.jenisKelamin = jenisKelamin;
    }

    public void setTinggi(double tinggi) {
        this.tinggi = tinggi;
    }

    // Perhitungan Berat Badan Ideal (Rumus Broca)
    public double getBeratIdeal() {
        double beratIdeal;
        if (jenisKelamin == 1) {
            // Laki-laki: (Tinggi - 100) - ((Tinggi - 100) * 10%)
            beratIdeal = (tinggi - 100) - ((tinggi - 100) * 0.10);
        } else {
            // Perempuan: (Tinggi - 100) - ((Tinggi - 100) * 15%)
            beratIdeal = (tinggi - 100) - ((tinggi - 100) * 0.15);
        }
        return beratIdeal;
    }

    // Method untuk mengecek kategori golongan berat badan
    public void cekGolongan(double beratNyata) {
        double ideal = getBeratIdeal();
        System.out.println("Tinggi : " + tinggi + " cm");
        System.out.println("berat : " + beratNyata + " kg");
        System.out.printf("Berat badan ideal kamu yaitu : %.2f kg%n", ideal);

        // Evaluasi kategori
        if (beratNyata < ideal - 2) {
            System.out.println("Kamu kurus bestie");
        } else if (beratNyata > ideal + 2) {
            System.out.println("Kamu kelebihan berat badan bestie");
        } else {
            System.out.println("Kamu termasuk normal bestie");
        }
    }
}

// Subclass Timbangan Digital (Menerima input desimal / double)
class TimbanganDigital extends Timbangan {
    private double berat;

    public void setBerat(double berat) {
        this.berat = berat;
    }

    public double getBerat() {
        return berat;
    }

    public void tampilkanHasil() {
        cekGolongan(berat);
    }
}

// Subclass Timbangan Analog (Menerima input bulat / int)
class TimbanganAnalog extends Timbangan {
    private int berat;

    public void setBerat(int berat) {
        this.berat = berat;
    }

    public int getBerat() {
        return berat;
    }

    public void tampilkanHasil() {
        cekGolongan((double) berat);
    }
}

// Main Class (Program Utama)
public class t12 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("*** Ideal kah kamu?... yuk nimbang dulu... ***");
        System.out.println("Pilih : 1. Timbangan Digital    2. Timbangan Analog");
        System.out.print("Masukkan pilihan : ");
        int pilihan = scanner.nextInt();

        if (pilihan == 1) {
            TimbanganDigital td = new TimbanganDigital();
            System.out.println("--- Timbangan Digital ---");
            System.out.println("[0] Perempuan   [1] Laki-laki");
            System.out.print("Masukkan jenis kelamin kamu : ");
            td.setJenisKelamin(scanner.nextInt());

            System.out.print("Masukkan berat badan kamu, misal 60.7 : ");
            td.setBerat(scanner.nextDouble());

            System.out.print("Masukkan tinggi badan kamu, misal 179.8 : ");
            td.setTinggi(scanner.nextDouble());

            System.out.println("***Hasil Timbangan Kamu***");
            td.tampilkanHasil();

        } else if (pilihan == 2) {
            TimbanganAnalog ta = new TimbanganAnalog();
            System.out.println("--- Timbangan Analog ---");
            System.out.println("[0] Perempuan   [1] Laki-laki");
            System.out.print("Masukkan jenis kelamin kamu : ");
            ta.setJenisKelamin(scanner.nextInt());

            System.out.print("Masukkan berat badan kamu : ");
            ta.setBerat(scanner.nextInt());

            System.out.print("Masukkan tinggi badan kamu : ");
            ta.setTinggi(scanner.nextDouble());

            System.out.println("***Hasil Timbangan Kamu***");
            ta.tampilkanHasil();
        } else {
            System.out.println("Pilihan tidak valid!");
        }

        scanner.close();
    }
}