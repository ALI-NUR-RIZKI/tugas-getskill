import javax.swing.JOptionPane;

// Superclass Sekolah
class Sekolah {
    protected String nama;

    // Konstruktor
    public Sekolah() {
    }

    // Method info() yang akan di-override (Polymorphism)
    public void info() {
        JOptionPane.showMessageDialog(null, "Informasi Sekolah");
    }
}

// Subclass Guru
class Guru extends Sekolah {
    private int nip;
    private String mapel;

    // Konstruktor
    public Guru() {
    }

    // Method setter untuk data Guru
    public void setDataGuru(int nip, String nama, String mapel) {
        this.nip = nip;
        this.nama = nama;
        this.mapel = mapel;
    }

    // Getter
    public int getNip() {
        return nip;
    }

    public String getNama() {
        return nama;
    }

    public String getMapel() {
        return mapel;
    }

    // Overriding method info()
    @Override
    public void info() {
        String data = "=== DATA GURU ===\n" +
                      "NIP          : " + nip + "\n" +
                      "Nama Guru    : " + nama + "\n" +
                      "Mata Pelajaran: " + mapel;
        JOptionPane.showMessageDialog(null, data, "Info Guru", JOptionPane.INFORMATION_MESSAGE);
    }
}

// Subclass Siswa
class Siswa extends Sekolah {
    private int nis;
    private int uts;
    private int uas;
    private int nilaiAkhir;

    // Konstruktor
    public Siswa() {
    }

    // Method untuk input data siswa via JOptionPane
    public void inputDataSiswa() {
        try {
            String strNis = JOptionPane.showInputDialog(null, "Masukkan NIS Siswa:", "Input Data Siswa", JOptionPane.QUESTION_MESSAGE);
            if (strNis == null) return;
            this.nis = Integer.parseInt(strNis);

            this.nama = JOptionPane.showInputDialog(null, "Masukkan Nama Siswa:", "Input Data Siswa", JOptionPane.QUESTION_MESSAGE);

            String strUts = JOptionPane.showInputDialog(null, "Masukkan Nilai UTS:", "Input Data Siswa", JOptionPane.QUESTION_MESSAGE);
            if (strUts == null) return;
            this.uts = Integer.parseInt(strUts);

            String strUas = JOptionPane.showInputDialog(null, "Masukkan Nilai UAS:", "Input Data Siswa", JOptionPane.QUESTION_MESSAGE);
            if (strUas == null) return;
            this.uas = Integer.parseInt(strUas);

            // Perhitungan nilai akhir (Rata-rata UTS & UAS)
            this.nilaiAkhir = (uts + uas) / 2;
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Input angka tidak valid!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Getter
    public int getNis() {
        return nis;
    }

    public String getNama() {
        return nama;
    }

    public int getUts() {
        return uts;
    }

    public int getUas() {
        return uas;
    }

    public double getNilaiAkhir() {
        return nilaiAkhir;
    }

    // Method konversi Nilai Huruf
    public String getNilaiHuruf() {
        if (nilaiAkhir >= 85) return "A";
        else if (nilaiAkhir >= 75) return "B";
        else if (nilaiAkhir >= 60) return "C";
        else if (nilaiAkhir >= 50) return "D";
        else return "E";
    }

    // Overriding method info()
    @Override
    public void info() {
        String data = "=== DATA SISWA ===\n" +
                      "NIS         : " + nis + "\n" +
                      "Nama Siswa  : " + nama + "\n" +
                      "Nilai UTS   : " + uts + "\n" +
                      "Nilai UAS   : " + uas + "\n" +
                      "Nilai Akhir : " + getNilaiAkhir() + "\n" +
                      "Nilai Huruf : " + getNilaiHuruf();
        JOptionPane.showMessageDialog(null, data, "Info Siswa", JOptionPane.INFORMATION_MESSAGE);
    }
}

// Main Class (Wajib bernama TesSekolah.java)
public class t10 {
    public static void main(String[] args) {
        boolean berjalan = true;

        while (berjalan) {
            String menu = "=== SYSTEM AKADEMIK SEKOLAH ===\n" +
                          "1. Input & Tampil Data Guru\n" +
                          "2. Input & Tampil Data Siswa\n" +
                          "3. Keluar\n\n" +
                          "Pilih menu (1-3):";

            String pilihan = JOptionPane.showInputDialog(null, menu, "Menu Utama", JOptionPane.QUESTION_MESSAGE);

            if (pilihan == null || pilihan.equals("3")) {
                JOptionPane.showMessageDialog(null, "Program Selesai!");
                berjalan = false;
            } else {
                // Konsep Polymorphism: Variabel bertipe Superclass
                Sekolah obj;

                switch (pilihan) {
                    case "1":
                        Guru g = new Guru();
                        try {
                            String strNip = JOptionPane.showInputDialog(null, "Masukkan NIP Guru:");
                            if (strNip == null) break;
                            int nip = Integer.parseInt(strNip);

                            String namaGuru = JOptionPane.showInputDialog(null, "Masukkan Nama Guru:");
                            String mapel = JOptionPane.showInputDialog(null, "Masukkan Mata Pelajaran:");

                            g.setDataGuru(nip, namaGuru, mapel);

                            // Pemanggilan polymorphism
                            obj = g;
                            obj.info();
                        } catch (NumberFormatException e) {
                            JOptionPane.showMessageDialog(null, "NIP harus berupa angka!", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                        break;

                    case "2":
                        Siswa s = new Siswa();
                        s.inputDataSiswa();

                        // Pemanggilan polymorphism
                        obj = s;
                        obj.info();
                        break;

                    default:
                        JOptionPane.showMessageDialog(null, "Pilihan tidak valid!", "Error", JOptionPane.WARNING_MESSAGE);
                }
            }
        }
    }
}