class t2 {
    // Atribut/Properties (private)
    private String kecepatan;
    private int roda;
    private String tipe;

    // --- Setter Methods ---
    public void setKecepatan(String kecepatan) {
        this.kecepatan = kecepatan;
    }

    public void setRoda(int roda) {
        this.roda = roda;
    }

    public void setTipe(String tipe) {
        this.tipe = tipe;
    }

    // --- Getter Methods ---
    public String getKecepatan() {
        return kecepatan;
    }

    public int getRoda() {
        return roda;
    }

    public String getTipe() {
        return tipe;
    }

    // Method untuk menampilkan spesifikasi mobil
    public void tampilkanSpesifikasi() {
        System.out.println("Kecepatan : " + kecepatan);
        System.out.println("Roda      : " + roda);
        System.out.println("Tipe      : " + tipe);
    }
}

// Class Main (Program Utama)
class Main {
    public static void main(String[] args) {
        // Membuat object Mobil Avanza
        t2 avanza = new t2();

        // Mengisi nilai atribut menggunakan method setter
        avanza.setKecepatan("270 km/h");
        avanza.setRoda(4);
        avanza.setTipe("CUV");

        // Menampilkan hasil
        System.out.println("=== Spesifikasi Mobil Avanza ===");
        avanza.tampilkanSpesifikasi();
    }
}