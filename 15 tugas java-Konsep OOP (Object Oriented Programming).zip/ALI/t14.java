// Interface WiFi
interface WiFi {
    void sendData();
}

// Interface Radio
interface Radio {
    void sendSignal();
}

// Superclass Computer
class Computer {
    protected String ipAddress;
    protected int cpuClock;
    protected int memory;
    protected int storage;

    public void getInfo() {
        System.out.println("Computer Info");
    }
}

// Subclass Desktop (Mewarisi Computer dan Mengimplementasikan Interface WiFi)
class Desktop extends Computer implements WiFi {
    @Override
    public void sendData() {
        System.out.println("Controlling data desktop via wifi...");
    }
}

// Subclass RaspberryPi (Mewarisi Computer dan Mengimplementasikan Multiple Interface WiFi & Radio)
class RaspberryPi extends Computer implements WiFi, Radio {
    @Override
    public void sendData() {
        System.out.println("Controlling data raspberrypi via wifi...");
    }

    @Override
    public void sendSignal() {
        System.out.println("Controlling data raspberrypi via radio...");
    }
}

// Subclass Drone (Mengimplementasikan Multiple Interface WiFi & Radio)
class Drone implements WiFi, Radio {
    @Override
    public void sendData() {
        System.out.println("Controlling data drone via wifi...");
    }

    @Override
    public void sendSignal() {
        System.out.println("Controlling data drone via radio...");
    }
}

// Class Operator untuk mengontrol perangkat melalui WiFi dan Radio
class Operator {
    public void wifiControl(WiFi wifi) {
        wifi.sendData();
    }

    public void radioControl(Radio radio) {
        radio.sendSignal();
    }
}

// Main Class 
public class t14 {
    public static void main(String[] args) {
        Operator op = new Operator();

        Desktop desktop = new Desktop();
        RaspberryPi raspberryPi = new RaspberryPi();
        Drone drone = new Drone();

        // Pengujian kontrol via WiFi
        op.wifiControl(desktop);
        op.wifiControl(raspberryPi);
        op.wifiControl(drone);

        // Pengujian kontrol via Radio
        op.radioControl(raspberryPi);
        op.radioControl(drone);
    }
}