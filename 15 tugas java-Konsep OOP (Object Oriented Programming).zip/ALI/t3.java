public class t3 {
    public static void main(String[] args) {
        // Data nama siswa
        String[] siswa = {"Ahmad", "Burhan", "Cintia", "Dona", "EJava"};

        // Array 2D jawaban 5 siswa (10 soal per siswa)
        char[][] jawabanSiswa = {
            {'A', 'B', 'A', 'C', 'C', 'D', 'D', 'A', 'B', 'B'}, // Ahmad
            {'D', 'B', 'C', 'B', 'C', 'B', 'C', 'A', 'C', 'B'}, // Burhan
            {'A', 'A', 'A', 'C', 'C', 'D', 'D', 'A', 'C', 'B'}, // Cintia
            {'B', 'B', 'A', 'B', 'C', 'A', 'D', 'A', 'B', 'B'}, // Dona
            {'A', 'A', 'A', 'B', 'C', 'D', 'C', 'B', 'A', 'B'}  // EJava
        };

        // Kunci jawaban (10 soal)
        char[] kunciJawaban = {'B', 'B', 'A', 'D', 'C', 'B', 'D', 'A', 'B', 'B'};

        System.out.println("==================================================");
        System.out.println("           HASIL PENILAIAN UJIAN SISWA            ");
        System.out.println("==================================================");

        // Perulangan untuk mengecek jawaban setiap siswa
        for (int i = 0; i < jawabanSiswa.length; i++) {
            int jumlahBenar = 0;

            // Perulangan untuk membandingkan jawaban dengan kunci
            for (int j = 0; j < kunciJawaban.length; j++) {
                if (jawabanSiswa[i][j] == kunciJawaban[j]) {
                    jumlahBenar++;
                }
            }

            // Perhitungan nilai (Benar * 10)
            int nilai = jumlahBenar * 10;

            // Penentuan status kelulusan (LULUS jika nilai >= 70, selain itu GAGAL)
            String status = (nilai >= 70) ? "LULUS" : "GAGAL";

            // Menampilkan hasil
            System.out.printf("%-8s | Benar: %2d | Nilai: %3d | Status: %s%n", 
                              siswa[i], jumlahBenar, nilai, status);
        }
        System.out.println("==================================================");
    }
}