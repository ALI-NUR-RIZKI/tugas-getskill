import java.util.ArrayList;
import java.util.Scanner;

// Superclass RumahSakit
class RumahSakit {
    protected String namaRS;

    public void setNamaRS(String namaRS) {
        this.namaRS = namaRS;
    }

    public String getNamaRS() {
        return namaRS;
    }
}

// Subclass Dokter
class Dokter extends RumahSakit {
    protected String namaDokter;
    protected String spesialis;

    public void setDataDokter(String namaDokter, String spesialis) {
        this.namaDokter = namaDokter;
        this.spesialis = spesialis;
    }
}

// Subclass Pasien (Mewarisi Dokter)
class Pasien extends Dokter {
    private String namaPasien;
    private String penyakit;
    private String noKamar;
    private String ktp;

    // Method setData sesuai struktur UML
    public void setData(String namaRS, String ktp, String namaPasien, String penyakit, String noKamar, String namaDokter, String spesialis) {
        setNamaRS(namaRS);
        this.ktp = ktp;
        this.namaPasien = namaPasien;
        this.penyakit = penyakit;
        this.noKamar = noKamar;
        setDataDokter(namaDokter, spesialis);
    }

    public String getKtp() {
        return ktp;
    }

    // Method tampil() untuk mencetak data pasien
    public void tampil(int index) {
        System.out.println("---" + index + "---");
        System.out.println("RUMAH SAKIT   : " + namaRS);
        System.out.println("Nomer KTP     : " + ktp);
        System.out.println("Nama Pasien   : " + namaPasien);
        System.out.println("Penyakit Pasien : " + penyakit);
        System.out.println("nomer Kamar   : " + noKamar);
        System.out.println("Nama Dokter   : " + namaDokter);
        System.out.println("Spesialis     : " + spesialis);
    }
}

// Class Main (Program Utama)
public class t8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Pasien> daftarPasien = new ArrayList<>();
        boolean berjalan = true;

        while (berjalan) {
            System.out.println("\n1. Input");
            System.out.println("2. Update");
            System.out.println("3. View");
            System.out.println("4. Exit");
            System.out.print("pilihan : ");

            int pilihan = scanner.nextInt();
            scanner.nextLine(); // Membersihkan buffer newline

            switch (pilihan) {
                case 1:
                    Pasien pasienBaru = new Pasien();
                    System.out.print("Masukkan Nama Rumah Sakit: ");
                    String rs = scanner.nextLine();
                    System.out.print("Masukkan Nomer KTP       : ");
                    String ktp = scanner.nextLine();
                    System.out.print("Masukkan Nama Pasien     : ");
                    String namaPasien = scanner.nextLine();
                    System.out.print("Masukkan Penyakit Pasien : ");
                    String penyakit = scanner.nextLine();
                    System.out.print("Masukkan nomer Kamar     : ");
                    String noKamar = scanner.nextLine();
                    System.out.print("Masukkan Nama Dokter     : ");
                    String namaDokter = scanner.nextLine();
                    System.out.print("Masukkan Spesialis       : ");
                    String spesialis = scanner.nextLine();

                    pasienBaru.setData(rs, ktp, namaPasien, penyakit, noKamar, namaDokter, spesialis);
                    daftarPasien.add(pasienBaru);
                    System.out.println("Data pasien berhasil ditambahkan!");
                    break;

                case 2:
                    System.out.print("Masukkan Nomer KTP data yang akan di-update: ");
                    String targetKtp = scanner.nextLine();
                    boolean ditemukan = false;

                    for (Pasien p : daftarPasien) {
                        if (p.getKtp().equalsIgnoreCase(targetKtp)) {
                            System.out.print("Masukkan Nama Rumah Sakit Baru: ");
                            String rsBaru = scanner.nextLine();
                            System.out.print("Masukkan Nama Pasien Baru    : ");
                            String namaPasienBaru = scanner.nextLine();
                            System.out.print("Masukkan Penyakit Pasien Baru: ");
                            String penyakitBaru = scanner.nextLine();
                            System.out.print("Masukkan nomer Kamar Baru    : ");
                            String noKamarBaru = scanner.nextLine();
                            System.out.print("Masukkan Nama Dokter Baru    : ");
                            String namaDokterBaru = scanner.nextLine();
                            System.out.print("Masukkan Spesialis Baru      : ");
                            String spesialisBaru = scanner.nextLine();

                            p.setData(rsBaru, targetKtp, namaPasienBaru, penyakitBaru, noKamarBaru, namaDokterBaru, spesialisBaru);
                            System.out.println("Data pasien berhasil diperbarui!");
                            ditemukan = true;
                            break;
                        }
                    }

                    if (!ditemukan) {
                        System.out.println("Data pasien dengan KTP " + targetKtp + " tidak ditemukan.");
                    }
                    break;

                case 3:
                    if (daftarPasien.isEmpty()) {
                        System.out.println("Belum ada data pasien.");
                    } else {
                        for (int i = 0; i < daftarPasien.size(); i++) {
                            daftarPasien.get(i).tampil(i + 1);
                        }
                    }
                    break;

                case 4:
                    System.out.println("Program selesai. Terima kasih!");
                    berjalan = false;
                    break;

                default:
                    System.out.println("Pilihan tidak valid! Silakan masukkan angka 1-4.");
            }
        }

        scanner.close();
    }
}