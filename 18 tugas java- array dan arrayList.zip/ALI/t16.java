import java.util.ArrayList;

public class t16 {
    public static void main(String[] args) {
        // Deklarasi ArrayList bertipe Object untuk menyimpan multi tipe data (String & Integer)
        ArrayList<Object> data = new ArrayList<>();

        // Menambahkan data nama (String) dan usia (Integer) secara bergantian
        data.add("Heru Hermawan");
        data.add(17);
        data.add("Angga Ariyanto");
        data.add(16);
        data.add("Ratih Isabela");
        data.add(15);

        System.out.println("Daftar Nama dan Usia:");

        // Perulangan dan pengecekan tipe data menggunakan instanceof
        for (int i = 0; i < data.size(); i++) {
            if (data.get(i) instanceof String) {
                // Menampilkan nama
                System.out.print("Nama: " + data.get(i));
            } else if (data.get(i) instanceof Integer) {
                // Menampilkan usia
                System.out.println(" | Usia: " + data.get(i));
            }
        }
    }
}