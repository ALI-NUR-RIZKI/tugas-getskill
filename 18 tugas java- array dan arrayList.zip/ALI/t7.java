public class t7 {
    public static void main(String[] args) {
        // Inisialisasi Array 2 Dimensi (5 Baris x 3 Kolom)
        // Kolom 0: Merk | Kolom 1: Tipe | Kolom 2: Harga
        String[][] hpData = {
            {"Xiaomi", "Poco M3", "1850000"},
            {"Oppo", "Reno 6", "4299000"},
            {"VIVO", "Y21", "1635000"},
            {"Oppo", "A15", "1618500"},
            {"Samsung", "Galaxy A12", "1990000"}
        };

        // Header Tabel
        System.out.println("=================================================");
        System.out.printf("| %-3s | %-10s | %-12s | %-10s |\n", "No.", "Merk", "Tipe", "Harga");
        System.out.println("=================================================");

        // Mengakses dan menampilkan isi Array 2 Dimensi menggunakan Nested Loop
        for (int i = 0; i < hpData.length; i++) {
            System.out.printf("| %-3d | %-10s | %-12s | %-10s |\n", 
                (i + 1), 
                hpData[i][0], 
                hpData[i][1], 
                hpData[i][2]
            );
        }

        System.out.println("=================================================");
    }
}