public class t4{
    public static void main(String[] args) {
        // Deklarasi array angka sesuai instruksi soal
        int angka[] = {10, 9, 30, 45, 78, 34, 11, 8, 5, 45, 90, 102, 56, 3};

        System.out.println("Angka Ganjil dari Array:");

        // Perulangan untuk mengecek setiap elemen dalam array
        for (int i = 0; i < angka.length; i++) {
            // Syarat ganjil: sisa hasil bagi (%) dengan 2 tidak sama dengan 0
            if (angka[i] % 2 != 0) {
                System.out.print(angka[i] + " ");
            }
        }

        System.out.println(); // Baris baru
    }
}