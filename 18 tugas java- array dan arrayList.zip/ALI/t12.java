public class t12 {
    public static void main(String[] args) {
        // Deklarasi Matriks A (2x2)
        int[][] matriksA = {
            {4, 5},
            {3, 2}
        };

        // Deklarasi Matriks B (2x2)
        int[][] matriksB = {
            {6, 2},
            {8, 4}
        };

        // Matriks untuk menyimpan hasil penjumlahan
        int[][] hasil = new int[2][2];

        // Menampilkan Matriks A
        System.out.println("Matriks A");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                System.out.print(matriksA[i][j] + "\t");
            }
            System.out.println();
        }

        System.out.println(); // Baris baru

        // Menampilkan Matriks B
        System.out.println("Matriks B");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                System.out.print(matriksB[i][j] + "\t");
            }
            System.out.println();
        }

        System.out.println(); // Baris baru

        // Proses penjumlahan kedua matriks
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                hasil[i][j] = matriksA[i][j] + matriksB[i][j];
            }
        }

        // Menampilkan Hasil Penjumlahan
        System.out.println("Hasil penjumlahan Matriks A + Matriks B");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                System.out.print(hasil[i][j] + "\t");
            }
            System.out.println();
        }
    }
}