import java.util.Scanner;

public class t6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Menerima input jumlah elemen (n) dari user
        System.out.print("Masukkan jumlah angka (n): ");
        int n = scanner.nextInt();

        // Deklarasi array dengan ukuran sebesar n
        int[] angka = new int[n];

        System.out.println(); // Baris baru

        // Perulangan untuk menerima input angka sebanyak n
        for (int i = 0; i < n; i++) {
            System.out.print("Masukkan angka ke-" + (i + 1) + ": ");
            angka[i] = scanner.nextInt();
        }

        // Inisialisasi variabel max dengan elemen pertama array
        int max = angka[0];

        // Perulangan untuk mencari angka terbesar (maksimal)
        for (int i = 1; i < n; i++) {
            if (angka[i] > max) {
                max = angka[i];
            }
        }

        System.out.println("\n=================================");
        
        // Menampilkan seluruh angka yang disimpan di array
        System.out.print("Angka yang diinputkan: ");
        for (int i = 0; i < n; i++) {
            System.out.print(angka[i] + (i < n - 1 ? ", " : ""));
        }

        // Menampilkan angka terbesar
        System.out.println("\nAngka Terbesar (Maksimal): " + max);
        System.out.println("=================================");

        scanner.close();
    }
}