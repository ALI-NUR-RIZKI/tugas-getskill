import java.util.ArrayList;
import java.util.Scanner;

public class t17 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<String> merkLaptop = new ArrayList<>();
        int pilihan;

        do {
            // Tampilan Pilihan Menu
            System.out.println("\n=== PILIHAN MENU ===");
            System.out.println("1. Menambahkan data nama merk laptop");
            System.out.println("2. Melihat daftar nama merk laptop");
            System.out.println("0. Keluar");
            System.out.print("Pilih menu (0-2): ");
            pilihan = scanner.nextInt();
            scanner.nextLine(); // Membersihkan buffer newline

            switch (pilihan) {
                case 1:
                    // Menu 1: Menambahkan data ke ArrayList
                    System.out.print("\nMasukkan nama merk laptop: ");
                    String laptopBaru = scanner.nextLine();
                    merkLaptop.add(laptopBaru);
                    System.out.println("-> Merk laptop '" + laptopBaru + "' berhasil ditambahkan!");
                    break;

                case 2:
                    // Menu 2: Melihat daftar data di ArrayList
                    System.out.println("\n=== DAFTAR MERK LAPTOP ===");
                    if (merkLaptop.isEmpty()) {
                        System.out.println("(Belum ada data merk laptop yang tersimpan)");
                    } else {
                        for (int i = 0; i < merkLaptop.size(); i++) {
                            System.out.println((i + 1) + ". " + merkLaptop.get(i));
                        }
                    }
                    break;

                case 0:
                    // Menu 0: Keluar dari program
                    System.out.println("\nTerima kasih! Program selesai.");
                    break;

                default:
                    System.out.println("\nPilihan menu tidak valid! Silakan pilih 1, 2, atau 0.");
                    break;
            }

        } while (pilihan != 0); // Perulangan berhenti jika pilihan == 0

        scanner.close();
    }
}