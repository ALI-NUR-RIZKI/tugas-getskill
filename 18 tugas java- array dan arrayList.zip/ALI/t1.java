public class t1 {
    public static void main(String[] args) {
        // Deklarasi array 1 dimensi berisi bagian kata dari nama
        String[] nama = {"Mudafiq", "Riyan", "Pratama"};

        // Menampilkan anggota array menjadi satu-kesatuan nama menggunakan perulangan
        System.out.print("Nama Lengkap: ");
        for (int i = 0; i < nama.length; i++) {
            System.out.print(nama[i] + " ");
        }

        System.out.println(); // Baris baru
    }
}