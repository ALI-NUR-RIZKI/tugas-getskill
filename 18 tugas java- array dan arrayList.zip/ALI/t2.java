import javax.swing.JOptionPane;

public class t2 {
    public static void main(String[] args) {
        // Deklarasi array 1 dimensi dengan alokasi 5 elemen
        String siswa[] = new String[5];

        // Perulangan untuk menerima inputan user dan menyimpan ke dalam array
        for (int i = 0; i < siswa.length; i++) {
            siswa[i] = JOptionPane.showInputDialog(null, 
                "Masukkan nama siswa ke-" + (i + 1) + ":", 
                "Input Data Siswa", 
                JOptionPane.QUESTION_MESSAGE);
        }

        // Menyusun teks hasil output dari array
        StringBuilder hasil = new StringBuilder("=== DAFTAR NAMA SISWA ===\n\n");
        for (int i = 0; i < siswa.length; i++) {
            hasil.append((i + 1)).append(". ").append(siswa[i]).append("\n");
        }

        // Menampilkan isi array menggunakan JOptionPane
        JOptionPane.showMessageDialog(null, 
            hasil.toString(), 
            "Hasil Data Siswa", 
            JOptionPane.INFORMATION_MESSAGE);
    }
}