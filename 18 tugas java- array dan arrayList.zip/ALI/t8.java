public class t8 {
    public static void main(String[] args) {
        // Deklarasi Array 2 Dimensi 4 Baris x 2 Kolom
        // Kolom 0: Nama Depan | Kolom 1: Nama Belakang
        String[][] nama = {
            {"Sugito", "Prayoga"},
            {"Samirul", "Hilmi"},
            {"Leo", "Hermawan"},
            {"Triawan", "Angga"}
        };

        // Perulangan untuk mengiterasi baris dan menggabungkan nama depan + nama belakang
        for (int i = 0; i < nama.length; i++) {
            System.out.println((i + 1) + ". " + nama[i][0] + " " + nama[i][1]);
        }
    }
}