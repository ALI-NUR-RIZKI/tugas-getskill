import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class t3 {
    public static void main(String[] args) throws IOException {
        // Inisialisasi BufferedReader untuk membaca input dari keyboard
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        // Deklarasi array 1 dimensi untuk 3 merk laptop dan 3 merk handphone
        String[] merkLaptop = new String[3];
        String[] merkHP = new String[3];

        // Input 3 data merk laptop
        System.out.println("=== INPUT DATA MERK LAPTOP ===");
        for (int i = 0; i < merkLaptop.length; i++) {
            System.out.print("Masukkan merk laptop ke-" + (i + 1) + ": ");
            merkLaptop[i] = reader.readLine();
        }

        System.out.println(); // Baris baru

        // Input 3 data merk handphone
        System.out.println("=== INPUT DATA MERK HANDPHONE ===");
        for (int i = 0; i < merkHP.length; i++) {
            System.out.print("Masukkan merk handphone ke-" + (i + 1) + ": ");
            merkHP[i] = reader.readLine();
        }

        System.out.println("\n=================================");
        System.out.println("       DAFTAR GADGET TERSIMPAN   ");
        System.out.println("=================================");

        // Menampilkan data laptop dari array
        System.out.println("\nMerk Laptop:");
        for (int i = 0; i < merkLaptop.length; i++) {
            System.out.println((i + 1) + ". " + merkLaptop[i]);
        }

        // Menampilkan data handphone dari array
        System.out.println("\nMerk Handphone:");
        for (int i = 0; i < merkHP.length; i++) {
            System.out.println((i + 1) + ". " + merkHP[i]);
        }
    }
}