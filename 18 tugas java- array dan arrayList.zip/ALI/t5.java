import java.util.Scanner;

public class t5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Menerima input jumlah elemen (n) dari user
        System.out.print("Masukkan jumlah angka (n): ");
        int n = scanner.nextInt();

        // Deklarasi array dengan ukuran sebesar n
        int[] angka = new int[n];
        int total = 0;

        System.out.println(); // Baris baru

        // Perulangan untuk menerima input angka sebanyak n
        for (int i = 0; i < n; i++) {
            System.out.print("Masukkan angka ke-" + (i + 1) + ": ");
            angka[i] = scanner.nextInt();
            
            // Menjumlahkan angka yang diinputkan ke dalam variabel total
            total += angka[i];
        }

        System.out.println("\n=================================");
        
        // Menampilkan seluruh angka yang diinputkan
        System.out.print("Angka yang diinputkan: ");
        for (int i = 0; i < n; i++) {
            System.out.print(angka[i] + (i < n - 1 ? ", " : ""));
        }

        // Menampilkan total penjumlahan angka
        System.out.println("\nTotal penjumlahan: " + total);
        System.out.println("=================================");

        scanner.close();
    }
}