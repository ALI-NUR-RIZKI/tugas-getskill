public class t10 {
    public static void main(String[] args) {
        // Array 1 Dimensi untuk Nama Siswa
        String[] namaSiswa = {
            "Kenzo Ismail",
            "Desmon Daffa",
            "Nayla Isabela",
            "Khansa Zakira"
        };

        // Array 2 Dimensi untuk Nilai (Nilai 1, Nilai 2, Nilai 3)
        double[][] nilai = {
            {81, 90, 62},
            {80, 82, 87},
            {89, 59, 85},
            {77, 73, 80}
        };

        System.out.println("=========================================================");
        System.out.printf("| %-3s | %-15s | %-6s | %-6s | %-6s | %-10s |\n", 
            "NO.", "Nama", "Nilai1", "Nilai2", "Nilai3", "Rata-Rata");
        System.out.println("=========================================================");

        // Mengiterasi setiap siswa dan menghitung rata-ratanya
        for (int i = 0; i < namaSiswa.length; i++) {
            double total = 0;
            
            // Loop untuk menjumlahkan nilai3 pelajaran per siswa
            for (int j = 0; j < nilai[i].length; j++) {
                total += nilai[i][j];
            }

            // Menghitung rata-rata
            double rataRata = total / nilai[i].length;

            // Menampilkan data dalam bentuk tabel
            System.out.printf("| %-3d | %-15s | %-6.0f | %-6.0f | %-6.0f | %-10.2f |\n", 
                (i + 1), 
                namaSiswa[i], 
                nilai[i][0], 
                nilai[i][1], 
                nilai[i][2], 
                rataRata
            );
        }

        System.out.println("=========================================================");
    }
}