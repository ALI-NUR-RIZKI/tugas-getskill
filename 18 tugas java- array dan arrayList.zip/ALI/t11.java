import java.util.Scanner;

public class t11 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Menerima input jumlah data/siswa dari user
        System.out.print("Inputkan jumlah data: ");
        int n = scanner.nextInt();
        scanner.nextLine(); // Membersihkan buffer newline

        // Deklarasi array 1D untuk nama dan array 2D untuk 3 nilai tiap siswa
        String[] nama = new String[n];
        double[][] nilai = new double[n][3];

        // Loop untuk menginputkan nama seluruh siswa terlebih dahulu
        for (int i = 0; i < n; i++) {
            System.out.print("Inputkan nama ke-" + (i + 1) + ": ");
            nama[i] = scanner.nextLine();
        }

        // Loop untuk menginputkan nilai1, nilai2, dan nilai3 masing-masing siswa
        for (int i = 0; i < n; i++) {
            System.out.println("\nNilai " + nama[i] + ":");
            for (int j = 0; j < 3; j++) {
                System.out.print("Inputkan nilai" + (j + 1) + ": ");
                nilai[i][j] = scanner.nextDouble();
            }
        }

        // Menampilkan hasil tabel penilaian
        System.out.println("\n=========================================================================");
        System.out.printf("| %-3s | %-12s | %-6s | %-6s | %-6s | %-10s | %-11s |\n", 
            "NO.", "Nama", "Nilai1", "Nilai2", "Nilai3", "Rata-Rata", "Nilai Huruf");
        System.out.println("=========================================================================");

        for (int i = 0; i < n; i++) {
            double total = 0;
            for (int j = 0; j < 3; j++) {
                total += nilai[i][j];
            }
            double rataRata = total / 3;

            // Konversi nilai rata-rata menjadi Nilai Huruf
            String nilaiHuruf;
            if (rataRata >= 81 && rataRata <= 100) {
                nilaiHuruf = "Nilai A";
            } else if (rataRata >= 71 && rataRata < 81) {
                nilaiHuruf = "Nilai B";
            } else if (rataRata >= 51 && rataRata < 71) {
                nilaiHuruf = "Nilai C";
            } else if (rataRata >= 31 && rataRata < 51) {
                nilaiHuruf = "Nilai D";
            } else {
                nilaiHuruf = "Nilai E";
            }

            System.out.printf("| %-3d | %-12s | %-6.0f | %-6.0f | %-6.0f | %-10.2f | %-11s |\n", 
                (i + 1), 
                nama[i], 
                nilai[i][0], 
                nilai[i][1], 
                nilai[i][2], 
                rataRata, 
                nilaiHuruf
            );
        }

        System.out.println("=========================================================================");

        scanner.close();
    }
}