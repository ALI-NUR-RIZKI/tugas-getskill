import java.util.Scanner;

public class t13 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Deklarasi Matriks A, Matriks B, dan Matriks Hasil berordo 3x2 (3 baris x 2 kolom)
        int[][] matriksA = new int[3][2];
        int[][] matriksB = new int[3][2];
        int[][] hasil = new int[3][2];

        // Input Elemen Matriks A dari User
        System.out.println("=== INPUT MATRIKS A (3x2) ===");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 2; j++) {
                System.out.print("Matriks A [" + i + "][" + j + "]: ");
                matriksA[i][j] = scanner.nextInt();
            }
        }

        System.out.println(); // Baris baru

        // Input Elemen Matriks B dari User
        System.out.println("=== INPUT MATRIKS B (3x2) ===");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 2; j++) {
                System.out.print("Matriks B [" + i + "][" + j + "]: ");
                matriksB[i][j] = scanner.nextInt();
            }
        }

        // Proses Penjumlahan Matriks A dan Matriks B
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 2; j++) {
                hasil[i][j] = matriksA[i][j] + matriksB[i][j];
            }
        }

        System.out.println("\n=================================");
        System.out.println("     HASIL PENJUMLAHAN (A + B)   ");
        System.out.println("=================================");

        // Menampilkan Hasil Penjumlahan Matriks Ordo 3x2
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 2; j++) {
                System.out.print(hasil[i][j] + "\t");
            }
            System.out.println();
        }

        scanner.close();
    }
}