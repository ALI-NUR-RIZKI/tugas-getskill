import java.util.ArrayList;

public class t14 {
    public static void main(String[] args) {
        // Deklarasi dan pembuatan objek ArrayList untuk menyimpan nama tokoh
        ArrayList<String> namaTokoh = new ArrayList<>();

        // Operasi penambahan daftar nama tokoh teknologi
        namaTokoh.add("Steve Jobs");
        namaTokoh.add("Bill Gates");
        namaTokoh.add("Mark Zuckerberg");
        namaTokoh.add("Elon Musk");

        // Menampilkan daftar nama sebelum dilakukan penghapusan
        System.out.println("=== DAFTAR NAMA TOKOH SEBELUM REMOVE ===");
        for (int i = 0; i < namaTokoh.size(); i++) {
            System.out.println((i + 1) + ". " + namaTokoh.get(i));
        }

        // Operasi penghapusan data bernama "Bill Gates" dari ArrayList
        namaTokoh.remove("Bill Gates");

        System.out.println("\n=======================================");
        System.out.println(" (Bill Gates telah dihapus dari list)  ");
        System.out.println("=======================================\n");

        // Menampilkan daftar nama setelah dilakukan penghapusan
        System.out.println("=== DAFTAR NAMA TOKOH SETELAH REMOVE ===");
        for (int i = 0; i < namaTokoh.size(); i++) {
            System.out.println((i + 1) + ". " + namaTokoh.get(i));
        }
    }
}