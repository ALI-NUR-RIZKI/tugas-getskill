import java.util.ArrayList;
import java.util.Scanner;

public class t18 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Deklarasi ArrayList untuk menyimpan daftar angka (double/integer)
        ArrayList<Double> daftarAngka = new ArrayList<>();

        // Menerima input jumlah angka yang ingin dimasukkan user
        System.out.print("Masukkan jumlah angka yang ingin diinputkan (n): ");
        int n = scanner.nextInt();

        System.out.println(); // Baris baru

        // Perulangan untuk meminta input angka sebanyak n kali
        for (int i = 0; i < n; i++) {
            System.out.print("Masukkan angka ke-" + (i + 1) + ": ");
            double angka = scanner.nextDouble();
            
            // Menyimpan angka yang diinputkan ke dalam ArrayList
            daftarAngka.add(angka);
        }

        // Variabel untuk menampung total penjumlahan
        double total = 0;

        // Mengiterasi elemen ArrayList untuk menghitung total
        for (int i = 0; i < daftarAngka.size(); i++) {
            total += daftarAngka.get(i);
        }

        // Menhitung rata-rata angka
        double rataRata = total / daftarAngka.size();

        System.out.println("\n=================================");
        System.out.println("          HASIL PERHITUNGAN      ");
        System.out.println("=================================");

        // Menampilkan seluruh angka yang tersimpan di dalam ArrayList
        System.out.print("Angka di dalam ArrayList: ");
        for (int i = 0; i < daftarAngka.size(); i++) {
            System.out.print(daftarAngka.get(i) + (i < daftarAngka.size() - 1 ? ", " : ""));
        }

        // Menampilkan Total dan Rata-Rata
        System.out.println("\nTotal Angka : " + total);
        System.out.printf("Rata-Rata   : %.2f\n", rataRata);
        System.out.println("=================================");

        scanner.close();
    }
}