public class t9 {
    public static void main(String[] args) {
        // Inisialisasi Array 2 Dimensi sesuai data pada soal
        int[][] angka = {
            { 1,  2,  3,  4,  5 },
            { 6,  7,  8,  9, 10 },
            { 11, 12, 13, 14, 15 }
        };

        // Loop luar untuk mengiterasi setiap baris
        for (int i = 0; i < angka.length; i++) {
            int total = 0;
            System.out.print("Total Penjumlahan: ");

            // Loop dalam untuk mengakses setiap elemen kolom dan menghitung total
            for (int j = 0; j < angka[i].length; j++) {
                System.out.print(angka[i][j] + " ");
                total += angka[i][j]; // Menjumlahkan nilai elemen ke variabel total
            }

            // Menampilkan hasil penjumlahan untuk baris tersebut
            System.out.println("= " + total);
        }
    }
}