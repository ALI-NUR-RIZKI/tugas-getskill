import java.util.ArrayList;
import java.util.Arrays;

public class t15 {
    public static void main(String[] args) {
        // Inisialisasi ArrayList berisi angka 10, 20, 30, 40, 50 langsung di awal
        ArrayList<Integer> angka = new ArrayList<>(Arrays.asList(10, 20, 30, 40, 50));

        // Menampilkan isi ArrayList
        System.out.println("=== ISI ARRAYLIST ===");
        for (int i = 0; i < angka.size(); i++) {
            System.out.println("Elemen ke-" + (i + 1) + ": " + angka.get(i));
        }

        System.out.println("\nTotal elemen: " + angka.size());
    }
}