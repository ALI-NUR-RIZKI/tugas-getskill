public class tugas4 {
    public static void main(String[] args) {
        // Perulangan dari angka 1 hingga 100
        for (int i = 1; i <= 100; i++) {
            // Pengecekan apakah angka habis dibagi 2 (bilangan genap)
            if (i % 2 == 0) {
                System.out.print(i + " ");
            }
        }
    }
}
