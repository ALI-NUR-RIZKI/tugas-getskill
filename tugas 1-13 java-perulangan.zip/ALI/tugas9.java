import java.util.Scanner;

public class tugas9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Meminta input nilai faktorial dari user
        System.out.print("Masukkan angka untuk faktorial: ");
        int angka = scanner.nextInt();

        // Variabel penampung hasil perkalian (dimulai dari 1)
        long faktorial = 1;

        System.out.print("Faktorial dari " + angka + " adalah: ");

        // Perulangan menurun (decrement) selama i >= 1
        for (int i = angka; i >= 1; i--) {
            faktorial = faktorial * i;

            // Format tampilan proses perkalian (misal: 5*4*3*2*1)
            if (i > 1) {
                System.out.print(i + "*");
            } else {
                System.out.print(i);
            }
        }

        // Menampilkan hasil akhir
        System.out.println(" = " + faktorial);

        scanner.close();
    }
}