public class tugas8 {
    public static void main(String[] args) {
        // Inisialisasi variabel counter
        int i = 1;

        // Perulangan while running selama nilai i kurang dari atau sama dengan 10
        while (i <= 10) {
            System.out.println("Saya berjanji tidak akan mengulangi kesalahan lagi");
            
            // Increment untuk menambah nilai i sebesar 1 pada setiap putaran
            i++;
        }
    }
}