public class tugas5 {
    public static void main(String[] args) {
        // Perulangan dari angka 1 hingga 100
        for (int i = 1; i <= 100; i++) {
            // Pengecekan apakah sisa bagi 2 sama dengan 1 (bilangan ganjil)
            if (i % 2 == 1) {
                System.out.print(i + " ");
            }
        }
    }
}