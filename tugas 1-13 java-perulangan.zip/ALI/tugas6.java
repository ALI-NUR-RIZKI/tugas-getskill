public class tugas6 {
    public static void main(String[] args) {
        // Perulangan dari karakter 'A' hingga 'Z'
        for (char c = 'A'; c <= 'Z'; c++) {
            System.out.print(c + " ");
        }
    }
}