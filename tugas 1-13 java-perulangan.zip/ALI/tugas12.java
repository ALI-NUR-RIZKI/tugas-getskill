import java.util.Scanner;

public class tugas12 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int pilihan;

        // Perulangan akan terus berjalan hingga pengguna memilih menu 3 (Keluar)
        do {
            // Menampilkan daftar menu
            System.out.println("\n=== MENU PILIHAN ===");
            System.out.println("1. Penjumlahan");
            System.out.println("2. Pengurangan");
            System.out.println("3. Keluar");
            System.out.print("Pilih menu (1-3): ");
            pilihan = scanner.nextInt();

            // Memproses input pilihan menu pengguna
            switch (pilihan) {
                case 1:
                    System.out.println("Anda memilih menu PENJUMLAHAN");
                    break;
                case 2:
                    System.out.println("Anda memilih menu PENGURANGAN");
                    break;
                case 3:
                    System.out.println("Program berhenti!");
                    break;
                default:
                    System.out.println("Pilihan tidak valid, silakan coba lagi.");
                    break;
            }
        } while (pilihan != 3); // Perulangan berhenti jika pilihan == 3

        scanner.close();
    }
}