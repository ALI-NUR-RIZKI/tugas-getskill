import java.util.Scanner;

public class tugas7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Meminta input jumlah suku deret dari pengguna
        System.out.print("Masukkan jumlah deret yang ingin ditampilkan: ");
        int n = scanner.nextInt();

        // Inisialisasi angka awal deret dan penambahnya
        int nilai = 3;
        int penambah = 2;

        System.out.print("Hasil deret: ");
        
        // Perulangan untuk mencetak deret sebanyak n suku
        for (int i = 1; i <= n; i++) {
            System.out.print(nilai + " ");

            // Menambahkan nilai deret dengan penambah saat ini
            nilai = nilai + penambah;

            // Penambah bertambah 1 setiap putaran (increment 1)
            penambah++;
        }

        scanner.close();
    }
}