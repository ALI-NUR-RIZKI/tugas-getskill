import java.util.Scanner;

public class tugas10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Inisialisasi variabel boolean untuk mengontrol perulangan
        boolean running = true;
        int counter = 0;

        // Perulangan uncounted loop: terus berjalan selama variabel running bernilai true
        while (running) {
            counter++;
            System.out.println("Perulangan ke-" + counter);
            System.out.print("Apakah Anda ingin keluar dari perulangan? (ya/tidak): ");
            String jawab = scanner.nextLine();

            // Pengecekan kondisi berhenti
            if (jawab.equalsIgnoreCase("ya")) {
                running = false; // Mengubah running menjadi false untuk menghentikan loop
            }
        }

        System.out.println("Program selesai. Anda telah mengulang sebanyak " + counter + " kali.");
        scanner.close();
    }
}