public class tugas2 {
    public static void main(String[] args) {
        // Perulangan for dari 1 hingga 10
        for (int i = 1; i <= 10; i++) {
            System.out.println("Saya berjanji tidak akan mengulangi kesalahan lagi");
        }
    }
} 
