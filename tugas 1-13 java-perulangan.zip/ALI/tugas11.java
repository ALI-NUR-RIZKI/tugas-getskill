import java.util.Scanner;

public class tugas11 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Meminta input batas panjang deret dari pengguna
        System.out.print("Masukkan panjang deret: ");
        int batas = scanner.nextInt();

        // 1. Menampilkan Bilangan GANJIL menggunakan do-while
        System.out.print("Bilangan GANJIL: ");
        int i = 1;
        if (batas >= 1) {
            do {
                if (i % 2 != 0) {
                    System.out.print(i + " ");
                }
                i++;
            } while (i <= batas);
        }
        System.out.println(); // Pindah baris

        // 2. Menampilkan Bilangan GENAP menggunakan do-while
        System.out.print("Bilangan GENAP: ");
        int j = 1;
        if (batas >= 1) {
            do {
                if (j % 2 == 0) {
                    System.out.print(j + " ");
                }
                j++;
            } while (j <= batas);
        }
        System.out.println();

        scanner.close();
    }
}