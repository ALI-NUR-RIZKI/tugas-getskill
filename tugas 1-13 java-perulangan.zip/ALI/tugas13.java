import java.util.Scanner;

public class tugas13 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Meminta input jumlah deret Fibonacci dari pengguna
        System.out.print("Masukkan jumlah deret: ");
        int n = scanner.nextInt();

        // Mengatur dua suku awal Fibonacci
        int a = 1;
        int b = 1;
        int count = 1;

        System.out.print("Output: ");

        // Perulangan do-while hanya berjalan jika n > 0
        if (n > 0) {
            do {
                System.out.print(a + " ");

                // Menghitung suku berikutnya
                int next = a + b;
                a = b;
                b = next;

                count++;
            } while (count <= n);
        }

        scanner.close();
    }
}