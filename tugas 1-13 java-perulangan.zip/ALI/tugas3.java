public class tugas3 {
    public static void main(String[] args) {
        // Perulangan dari 50 ke 1 secara descending menggunakan decrement (i--)
        for (int i = 50; i >= 1; i--) {
            System.out.print(i + " ");
        }
    }
}
