import java.util.Scanner;

public class t1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Menerima input kalimat dari pengguna
        System.out.print("Masukkan Kalimat: ");
        String kalimat = scanner.nextLine();

        // Menghitung panjang string
        int panjang = kalimat.length();

        // Menampilkan jumlah karakter
        System.out.println("Jumlah Karakter: " + panjang);

        // Menentukan kondisi sesuai aturan tugas
        if (panjang < 10) {
            System.out.println("LOW");
        } else if (panjang >= 10 && panjang < 50) {
            System.out.println("MEDIUM");
        } else if (panjang >= 50) {
            System.out.println("HIGH");
        }

        scanner.close();
    }
}