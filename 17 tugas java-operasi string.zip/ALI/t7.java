import java.util.Scanner;

public class t7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Menerima input kalimat dari pengguna
        System.out.println("Masukkan Kalimat:");
        String kalimatAwal = scanner.nextLine();

        // Mengganti kata sesuai dengan instruksi tugas:
        // 1. "hewan" -> "binatang"
        // 2. "tangkai" -> "pohon"
        // 3. "tanaman" -> "tumbuhan"
        String kalimatHasil = kalimatAwal
                .replace("hewan", "binatang")
                .replace("tangkai", "pohon")
                .replace("tanaman", "tumbuhan");

        System.out.println("\n=== HASIL PERUBAHAN KALIMAT ===");
        System.out.println(kalimatHasil);

        scanner.close();
    }
}