public class t16 {
    public static void main(String[] args) {
        // Kalimat yang ditentukan pada tugas
        String kalimat = "Siswa kelas industri sangat antusias untuk belajar di hari sabtu";

        int jumlahSKecil = 0;
        int jumlahSBesar = 0;

        // Perulangan untuk mengecek setiap karakter dalam kalimat
        for (int i = 0; i < kalimat.length(); i++) {
            char c = kalimat.charAt(i);
            
            if (c == 's') {
                jumlahSKecil++;
            } else if (c == 'S') {
                jumlahSBesar++;
            }
        }

        int totalS = jumlahSKecil + jumlahSBesar;

        // Menampilkan hasil perhitungan
        System.out.println("Kalimat: " + kalimat);
        System.out.println("-------------------------------------------");
        System.out.println("Jumlah huruf 's' (kecil) : " + jumlahSKecil);
        System.out.println("Jumlah huruf 'S' (besar) : " + jumlahSBesar);
        System.out.println("Total huruf 's' dan 'S'  : " + totalS);
    }
}