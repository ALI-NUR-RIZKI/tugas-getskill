public class t8 {
    public static void main(String[] args) {
        // Kalimat 1: HUMMASOFT TECHNOLOGY MALANG (dikonversi ke lowercase)
        String kalimat1 = "HUMMASOFT TECHNOLOGY MALANG";
        String hasil1 = kalimat1.toLowerCase();

        // Kalimat 2: kelas industri bergengsi di indonesia (dikonversi ke uppercase)
        String kalimat2 = "kelas industri bergengsi di indonesia";
        String hasil2 = kalimat2.toUpperCase();

        // Kalimat 3: hummasoft (Uppercase) mempunyai produk (lowercase) sistem sekolah (Uppercase)
        String kataA = "hummasoft".toUpperCase();
        String kataB = " MEMPUNYAI PRODUK ".toLowerCase();
        String kataC = "sistem sekolah".toUpperCase();
        String hasil3 = kataA + kataB + kataC;

        // Menampilkan hasil keluaran program
        System.out.println("=== HASIL KONVERSI STRING ===");
        System.out.println("1. " + hasil1);
        System.out.println("2. " + hasil2);
        System.out.println("3. " + hasil3);
    }
}