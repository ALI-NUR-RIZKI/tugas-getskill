import java.util.Scanner;

public class t2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Menerima input kalimat dari pengguna
        System.out.println("Masukkan Kalimat:");
        String kalimat = scanner.nextLine();

        // Menghitung jumlah karakter
        int jumlahKarakter = kalimat.length();
        System.out.println(jumlahKarakter);

        double gajiPokok = 0;
        double bonus = 0;

        // Perhitungan Gaji Pokok Berdasarkan Ketentuan
        if (jumlahKarakter >= 100) {
            // Rp. 10.000 per 100 karakter (berlaku kelipatan)
            gajiPokok = (jumlahKarakter / 100) * 10000;
        } else if (jumlahKarakter > 50) {
            // Di atas 50 dan kurang dari 100 karakter
            gajiPokok = 5000;
        } else {
            // Kurang dari 50 karakter
            gajiPokok = 2000;
        }

        // Perhitungan Bonus (10% jika lebih dari 1000 karakter)
        if (jumlahKarakter > 1000) {
            bonus = gajiPokok * 0.10;
        }

        double totalGaji = gajiPokok + bonus;

        // Menampilkan Output
        System.out.println("gaji pokok " + (long) gajiPokok);
        if (jumlahKarakter > 1000) {
            System.out.println("gaji Bonus " + bonus);
        }
        System.out.println("Total Gaji Penulis " + (long) totalGaji);

        scanner.close();
    }
}