public class t12 {
    public static void main(String[] args) {
        // Kalimat yang ditentukan pada tugas
        String kalimat = "saya belajar pemrograman java bersama hummasoft di kelas industri.";

        // Menghitung jumlah karakter (termasuk spasi dan tanda baca)
        int jumlahKarakter = kalimat.length();

        // Memisahkan kalimat menjadi array kata berdasarkan spasi
        String[] kataArray = kalimat.trim().split("\\s+");
        
        // Menghitung jumlah kata
        int jumlahKata = kataArray.length;

        // Menampilkan output hasil perhitungan
        System.out.println("Kalimat: " + kalimat);
        System.out.println("-------------------------------------------");
        System.out.println("Jumlah Kata     : " + jumlahKata);
        System.out.println("Jumlah Karakter : " + jumlahKarakter);
    }
}