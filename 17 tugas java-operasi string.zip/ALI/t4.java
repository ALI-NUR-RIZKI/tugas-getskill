import java.util.Scanner;

public class t4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String nama = "";
        String alamat = "";
        String email = "";

        // Validasi Input Nama
        while (nama.trim().isEmpty()) {
            System.out.println("Masukkan Nama:");
            nama = scanner.nextLine();
            if (nama.trim().isEmpty()) {
                System.out.println("Nama Tidak boleh Kosong !");
            }
        }

        // Validasi Input Alamat
        while (alamat.trim().isEmpty()) {
            System.out.println("Masukkan Alamat:");
            alamat = scanner.nextLine();
            if (alamat.trim().isEmpty()) {
                System.out.println("Alamat Tidak boleh Kosong !");
            }
        }

        // Validasi Input Email
        while (email.trim().isEmpty()) {
            System.out.println("Masukkan Email:");
            email = scanner.nextLine();
            if (email.trim().isEmpty()) {
                System.out.println("Email Tidak boleh Kosong !");
            }
        }

        System.out.println("\n--- BIODATA BERHASIL DIINPUT ---");
        System.out.println("Nama   : " + nama);
        System.out.println("Alamat : " + alamat);
        System.out.println("Email  : " + email);

        scanner.close();
    }
}