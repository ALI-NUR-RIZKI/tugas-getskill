import java.util.Scanner;

public class t11 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Menerima input kalimat dari pengguna
        System.out.print("Masukkan Kalimat: ");
        String kalimat = scanner.nextLine();

        // Menerima input urutan karakter (misal: 2 untuk karakter ke-2)
        System.out.print("Masukkan Posisi Karakter yang Ingin Ditampilkan (dimulai dari 1): ");
        int posisi = scanner.nextInt();

        // Memisahkan kalimat menjadi kata-kata berdasarkan spasi
        String[] kataArray = kalimat.trim().split("\\s+");

        StringBuilder hasil = new StringBuilder();

        // Perulangan untuk mengambil karakter pada posisi yang ditentukan di setiap kata
        for (String kata : kataArray) {
            // Posisi 1 berbasis indeks 0 pada Java String (posisi - 1)
            int index = posisi - 1;

            // Mengecek apakah kata memiliki panjang karakter yang cukup
            if (index >= 0 && index < kata.length()) {
                hasil.append(kata.charAt(index));
            }
        }

        // Menampilkan hasil gabungan karakter
        System.out.println("\nHasil: " + hasil.toString());

        scanner.close();
    }
}