public class t15 {
    public static void main(String[] args) {
        // String awal yang ditentukan
        String teksAwal = "HUMMASOFT TECHNOLOGY";

        // Memisahkan teks menjadi kata-kata berdasarkan spasi
        String[] kataArray = teksAwal.toLowerCase().split("\\s+");
        StringBuilder hasil = new StringBuilder();

        // Mengubah huruf pertama pada setiap kata menjadi huruf besar
        for (String kata : kataArray) {
            if (!kata.isEmpty()) {
                // Karakter pertama diubah ke uppercase + sisa huruf tetap lowercase
                String kataCapitalCase = kata.substring(0, 1).toUpperCase() + kata.substring(1);
                hasil.append(kataCapitalCase).append(" ");
            }
        }

        // Menampilkan output hasil perubahan
        System.out.println("Teks Awal  : " + teksAwal);
        System.out.println("Teks Baku  : " + hasil.toString().trim());
    }
}