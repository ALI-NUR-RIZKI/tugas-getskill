public class t3 {
    public static void main(String[] args) {
        // Deklarasi array String dengan beberapa elemen terisi dan kosong/null
        String[] data = {"Array ke 1 Terisi", "Array ke 2 Terisi", "", "Array ke 4 Kosong", null};

        // Perulangan untuk mengecek setiap elemen array
        for (int i = 0; i < data.length; i++) {
            // Mengecek apakah elemen bernilai null atau string kosong (setelah di-trim)
            if (data[i] == null || data[i].trim().isEmpty()) {
                System.out.println("Array ke " + (i + 1) + " Kosong");
            } else {
                System.out.println("Array ke " + (i + 1) + " Terisi");
            }
        }
    }
}