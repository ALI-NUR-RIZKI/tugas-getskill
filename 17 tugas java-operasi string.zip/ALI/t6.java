public class t6 {
    public static void main(String[] args) {
        // Deklarasi array berisi beberapa kalimat
        String[] dataKalimat = {
            "Pemrograman Berorientasi Objek",
            "Materi Operasi String pada Java",
            "Penggunaan Array dan Perulangan",
            "Pengembangan Aplikasi Berbasis Java"
        };

        System.out.println("=== HASIL PENAMBAHAN NOMOR URUT ===");

        // Perulangan untuk menambahkan penomoran di awal kalimat
        for (int i = 0; i < dataKalimat.length; i++) {
            // Membuat string baru dengan menggabungkan nomor urut (i + 1) dan kalimat asli
            String kalimatBerpenomoran = (i + 1) + ". " + dataKalimat[i];

            // Menampilkan kalimat secara berurutan
            System.out.println(kalimatBerpenomoran);
        }
    }
}