public class t14 {
    public static void main(String[] args) {
        // String awal yang ditentukan pada tugas
        String kalimatAwal = "Aksara Jawa Hanacaraka Padajayanya";

        // Mengganti huruf 'A' (kapital) menjadi 'O' dan 'a' (kecil) menjadi 'o'
        String kalimatHasil = kalimatAwal
                .replace("A", "O")
                .replace("a", "o");

        // Menampilkan output hasil perubahan
        System.out.println("Kalimat Awal   : " + kalimatAwal);
        System.out.println("Kalimat Hasil  : " + kalimatHasil);
    }
}