import java.util.Scanner;

public class t9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Menerima input kalimat dari pengguna
        System.out.print("Masukkan Kalimat: ");
        String kalimat = scanner.nextLine();

        // Memisahkan kalimat berdasarkan spasi menggunakan split("\\s+")
        String[] kataArray = kalimat.trim().split("\\s+");

        System.out.println("\n=== HASIL PENGOLAHAN KATA ===");
        
        // Perulangan untuk memproses setiap kata
        for (int i = 0; i < kataArray.length; i++) {
            String kataAsli = kataArray[i];
            
            // Menghitung panjang karakter kata
            int panjangKata = kataAsli.length();
            
            // Mengubah kata menjadi huruf besar semua (Uppercase)
            String kataUppercase = kataAsli.toUpperCase();

            // Menampilkan output per kata
            System.out.println("Kata ke-" + (i + 1) + " : " + kataUppercase + " (Panjang: " + panjangKata + " karakter)");
        }

        scanner.close();
    }
}