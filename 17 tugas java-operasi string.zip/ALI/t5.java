public class t5 {
    public static void main(String[] args) {
        // Deklarasi array kalimat dengan beberapa nilai yang memiliki spasi berlebih, string kosong, atau null
        String[] dataKalimat = {
            "   Selamat Pagi   ",
            "  Belajar Java Operasi String  ",
            "   ",
            "",
            null,
            "   GetSkill Indonesia   "
        };

        System.out.println("=== HASIL MERAPIKAN KALIMAT ARRAY ===");

        // Perulangan untuk memproses dan merapikan setiap elemen array
        for (int i = 0; i < dataKalimat.length; i++) {
            String hasil;

            // Mengecek apakah elemen bernilai null
            if (dataKalimat[i] == null) {
                hasil = "-";
            } else {
                // Merapikan spasi di awal dan akhir string menggunakan trim()
                String rapi = dataKalimat[i].trim();

                // Jika setelah di-trim string menjadi kosong, ubah menjadi "-"
                if (rapi.isEmpty()) {
                    hasil = "-";
                } else {
                    hasil = rapi;
                }
            }

            // Menampilkan hasil
            System.out.println("Data ke-" + (i + 1) + " : " + hasil);
        }
    }
}