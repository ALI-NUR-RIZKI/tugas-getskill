public class t10 {
    public static void main(String[] args) {
        // Kalimat awal sesuai instruksi tugas
        String kalimat = "saya memancing ikan di sungai menggunakan pancingan yang panjang bersama teman saya yang berasal dari malang";

        // Array kata yang ingin dicari (kata awal)
        String[] kataCari = {"memancing", "sungai", "teman", "malang"};
        
        // Array kata pengganti yang sesuai dengan pasangan indeks kataCari
        String[] kataGanti = {"menjaring", "laut", "saudara", "surabaya"};

        // Menampilkan kalimat sebelum diubah
        System.out.println("Kalimat Awal:");
        System.out.println(kalimat);

        // Memproses pencocokan dan penggantian kata menggunakan array dan perulangan
        for (int i = 0; i < kataCari.length; i++) {
            if (kalimat.contains(kataCari[i])) {
                kalimat = kalimat.replace(kataCari[i], kataGanti[i]);
            }
        }

        // Menampilkan kalimat setelah diubah
        System.out.println("\nKalimat Setelah Diubah:");
        System.out.println(kalimat);
    }
}