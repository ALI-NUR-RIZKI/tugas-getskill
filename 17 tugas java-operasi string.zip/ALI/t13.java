public class t13 {
    public static void main(String[] args) {
        // Kata awal yang ditentukan
        String kataAwal = "hummasoft";

        // Mengonversi String menjadi Array Karakter (char[])
        char[] charArray = kataAwal.toCharArray();

        // Variabel untuk menampung hasil pembalikan kata
        String kataTerbalik = "";

        // Perulangan mundur dari indeks terakhir array hingga indeks ke-0
        for (int i = charArray.length - 1; i >= 0; i--) {
            kataTerbalik += charArray[i];
        }

        // Menampilkan output hasil pembalikan kata
        System.out.println("Kata Awal     : " + kataAwal);
        System.out.println("Kata Terbalik : " + kataTerbalik);
    }
}