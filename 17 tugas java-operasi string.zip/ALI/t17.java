import java.util.Scanner;

public class t17 {

    // Method pembantu untuk mengubah huruf besar dan kecil secara bergantian (Alternating Case)
    public static String toAlternatingCase(String input) {
        StringBuilder sb = new StringBuilder();
        boolean uppercase = true; // Karakter huruf pertama dimulai dengan kapital

        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            
            // Mengubah huruf secara bergantian jika merupakan karakter alfabet
            if (Character.isLetter(c)) {
                if (uppercase) {
                    sb.append(Character.toUpperCase(c));
                } else {
                    sb.append(Character.toLowerCase(c));
                }
                uppercase = !uppercase; // Balikkan status untuk huruf berikutnya
            } else {
                sb.append(c); // Karakter non-huruf (seperti spasi) tetap dipertahankan
            }
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // 1. Input Nama Depan & Nama Belakang
        System.out.print("Masukkan Nama Depan: ");
        String namaDepan = scanner.nextLine();

        System.out.print("Masukkan Nama Belakang: ");
        String namaBelakang = scanner.nextLine();

        // Menggabungkan nama depan dan belakang dipisahkan spasi
        String namaLengkap = namaDepan.trim() + " " + namaBelakang.trim();

        // 2. Input Lokasi Alamat (misal: "karangploso malang")
        System.out.print("Masukkan Lokasi Alamat (contoh: karangploso malang): ");
        String lokasiAlamat = scanner.nextLine();

        // Format kalimat alamat sesuai contoh: "alamat (nama lengkap) di (lokasi alamat)"
        String kalimatAlamat = "alamat " + namaLengkap + " di " + lokasiAlamat;

        // 3 & 4. Mengubah nama lengkap dan kalimat alamat menjadi huruf besar-kecil bergantian
        String namaLengkapAlternating = toAlternatingCase(namaLengkap);
        String kalimatAlamatAlternating = toAlternatingCase(kalimatAlamat);

        // Menampilkan Output
        System.out.println("\n=== HASIL MANIPULASI KALIMAT ===");
        System.out.println("Nama Lengkap Asli                  : " + namaLengkap);
        System.out.println("Nama Lengkap (Huruf Bergantian)    : " + namaLengkapAlternating);
        System.out.println("Kalimat Alamat Asli                : " + kalimatAlamat);
        System.out.println("Kalimat Alamat (Huruf Bergantian)  : " + kalimatAlamatAlternating);

        scanner.close();
    }
}