import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class tugas2 {
    public static void main(String[] args) {
        // Membuat objek BufferedReader untuk membaca input
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        try {
            // 1. Meminta input Nama Sekolah (String)
            System.out.print("Nama Sekolah: ");
            String namaSekolah = reader.readLine();

            // 2. Meminta input Jarak Rumah ke Sekolah (double)
            System.out.print("Jarak Rumah ke Sekolah (km): ");
            double jarakRumah = Double.parseDouble(reader.readLine());

            // 3. Meminta input Kode Plat Nomor Kendaraan (char)
            System.out.print("Kode Plat Nomor Kendaraan: ");
            char kodePlat = reader.readLine().charAt(0);

            // 4. Meminta input Anak Ke Berapa (int)
            System.out.print("Anak Ke Berapa: ");
            int anakKe = Integer.parseInt(reader.readLine());

            // Menampilkan output dari inputan yang telah dimasukkan
            System.out.println("\n--- HASIL INPUT BIODATA ---");
            System.out.println("Nama Sekolah: " + namaSekolah);
            System.out.println("Jarak Rumah ke Sekolah: " + jarakRumah + " km");
            System.out.println("Kode Plat Nomor Kendaraan: " + kodePlat);
            System.out.println("Anak Ke Berapa: " + anakKe);

        } catch (IOException e) {
            System.out.println("Terjadi kesalahan input: " + e.getMessage());
        }
    }
}
