import java.util.Scanner;

public class tugas1 {
    public static void main(String[] args) {
        // Membuat objek Scanner untuk membaca input dari keyboard
        Scanner scanner = new Scanner(System.in);

        // Meminta input nama lengkap (String)
        System.out.print("Masukkan nama lengkap: ");
        String nama = scanner.nextLine();

        // Meminta input usia (Integer)
        System.out.print("Masukkan usia: ");
        int usia = scanner.nextInt();

        // Membersihkan karakter newline setelah membaca angka
        scanner.nextLine();

        // Meminta input kota asal (String)
        System.out.print("Masukkan kota asal: ");
        String kotaAsal = scanner.nextLine();

        // Meminta input tinggi badan (Double/desimal)
        System.out.print("Masukkan tinggi badan (misal 160.0): ");
        double tinggiBadan = scanner.nextDouble();

        // Menampilkan output biodata
        System.out.println("\n--- BIODATA ---");
        System.out.println("Nama Lengkap : " + nama);
        System.out.println("Usia         : " + usia + " tahun");
        System.out.println("Kota Asal    : " + kotaAsal);
        System.out.println("Tinggi Badan : " + tinggiBadan + " cm");

        // Menutup Scanner
        scanner.close();
    }
}