import java.io.Console;

public class tugas3 {
    public static void main(String[] args) {
        // Mengambil objek Console dari System
        Console console = System.console();

        // Memastikan program dijalankan di lingkungan Console/Terminal
        if (console == null) {
            System.out.println("Console tidak tersedia. Jalankan program melalui Terminal/Command Prompt.");
            return;
        }

        // 1. Meminta input Jenis Kelamin (String)
        String jenisKelamin = console.readLine("Jenis Kelamin: ");

        // 2. Meminta input Nomor Sepatu (tipe int)
        int nomorSepatu = Integer.parseInt(console.readLine("Nomor Sepatu: "));

        // 3. Meminta input Sudah Menikah? (tipe boolean)
        boolean sudahMenikah = Boolean.parseBoolean(console.readLine("Sudah Menikah?: "));

        // Menampilkan output sesuai dengan inputan yang dimasukkan
        System.out.println("\n--- HASIL INPUT BIODATA ---");
        System.out.println("Jenis Kelamin : " + jenisKelamin);
        System.out.println("Nomor Sepatu  : " + nomorSepatu);
        System.out.println("Sudah Menikah?: " + sudahMenikah);
    }
}
