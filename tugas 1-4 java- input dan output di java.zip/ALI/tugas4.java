import javax.swing.JOptionPane;

public class tugas4 {
    public static void main(String[] args) {
        // 1. Meminta input Nama Lengkap (String)
        String namaLengkap = JOptionPane.showInputDialog(null, "Masukkan Nama Lengkap:");

        // 2. Meminta input Nomor Induk Siswa / NIS (String atau int)
        String nis = JOptionPane.showInputDialog(null, "Masukkan NIS:");

        // 3. Meminta input Umur (tipe int)
        String inputUmur = JOptionPane.showInputDialog(null, "Masukkan Umur:");
        int umur = Integer.parseInt(inputUmur);

        // Format pesan output yang akan ditampilkan
        String pesanOutput = "--- HASIL BIODATA ---\n"
                           + "Nama Lengkap: " + namaLengkap + "\n"
                           + "NIS: " + nis + "\n"
                           + "Umur: " + umur + " tahun";

        // Menampilkan output menggunakan Dialog Pesan (JOptionPane)
        JOptionPane.showMessageDialog(null, pesanOutput, "Detail Biodata", JOptionPane.INFORMATION_MESSAGE);
    }
}
