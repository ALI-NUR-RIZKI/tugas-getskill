public class t7 {
    public static void main(String[] args) {
        int baris = 5;
        int kolom = 5;

        // Loop luar untuk mengontrol baris (1 sampai 5)
        for (int i = 1; i <= baris; i++) {
            // Loop dalam untuk mencetak angka pada kolom sebanyak 5 kali
            for (int j = 1; j <= kolom; j++) {
                System.out.print(i + " ");
            }
            // Pindah ke baris baru setelah satu baris selesai dicetak
            System.out.println();
        }
    }
}