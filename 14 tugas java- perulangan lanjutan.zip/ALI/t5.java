public class t5 {
    public static void main(String[] args) {
        System.out.println("=== DERET ANGKA (5 DI AWAL & 5 DI AKHIR) ===");

        // Perulangan dari angka 1 sampai 20
        for (int i = 1; i <= 20; i++) {
            // Mengabaikan (skip) angka tengah (6 sampai 15)
            if (i > 5 && i < 16) {
                continue; // Melewati cetak angka 6 hingga 15
            }

            // Mencetak angka 1-5 dan 16-20
            System.out.print(i + " ");
        }

        System.out.println(); // Baris baru
    }
}