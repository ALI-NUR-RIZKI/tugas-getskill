public class t3 {
    public static void main(String[] args) {
        int a = 0;
        int b = 1;

        System.out.println("=== DERET FIBONACCI (NILAI < 200) ===");
        
        // Perulangan tak terhingga (infinite loop)
        while (true) {
            // Hentikan perulangan jika nilai deret sudah mencapai/melebihi 200
            if (a >= 200) {
                break;
            }

            // Tampilkan nilai deret saat ini
            System.out.print(a + " ");

            // Hitung suku berikutnya
            int next = a + b;
            a = b;
            b = next;
        }
        
        System.out.println(); // Baris baru
    }
}