import java.util.Scanner;

public class t14 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Menerima input tinggi piramida dari user
        System.out.print("Tinggi piramida: ");
        int tinggi = scanner.nextInt();

        System.out.println("Output:");

        // Loop luar untuk mengontrol baris (i dari 1 sampai tinggi)
        for (int i = 1; i <= tinggi; i++) {
            
            // Loop 1 (dalam): Mencetak spasi agar bintang terdorong ke tengah
            for (int j = 1; j <= tinggi - i; j++) {
                System.out.print(" ");
            }

            // Loop 2 (dalam): Mencetak bintang sebanyak (2 * i - 1)
            for (int k = 1; k <= (2 * i - 1); k++) {
                System.out.print("*");
            }

            // Pindah ke baris baru
            System.out.println();
        }

        scanner.close();
    }
}