public class t1 {
    public static void main(String[] args) {
        // Perulangan infinite loop yang dimulai dari i = 1
        for (int i = 1; i > 0; i++) {
            System.out.println("Angka: " + i);

            // Menghentikan perulangan saat variabel i mencapai angka 10
            if (i == 10) {
                break;
            }
        }
    }
}