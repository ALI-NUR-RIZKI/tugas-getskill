import java.util.Scanner;

public class t9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Menerima input jumlah sisi dari user
        System.out.print("Input: ");
        int sisi = scanner.nextInt();

        System.out.println("Output:");

        // Loop luar untuk mengontrol baris
        for (int i = 0; i < sisi; i++) {
            // Loop dalam untuk mencetak karakter bintang pada kolom
            for (int j = 0; j < sisi; j++) {
                System.out.print("* ");
            }
            // Pindah ke baris baru
            System.out.println();
        }

        scanner.close();
    }
}