import java.util.Scanner;

public class t13 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Menerima input tinggi/ukuran segitiga dari user
        System.out.print("Input: ");
        int tinggi = scanner.nextInt();

        System.out.println("Output:");

        // Loop luar untuk mengontrol baris (1 hingga tinggi)
        for (int i = 1; i <= tinggi; i++) {
            // Loop dalam untuk mencetak bintang sebanyak nomor baris (i)
            for (int j = 1; j <= i; j++) {
                System.out.print("* ");
            }
            // Pindah ke baris baru setelah satu baris bintang selesai
            System.out.println();
        }

        scanner.close();
    }
}