public class t4 {
    public static void main(String[] args) {
        System.out.println("=== DERET BILANGAN GENAP (1 s/d 20) ===");

        // Perulangan dari angka 1 sampai 20
        for (int i = 1; i <= 20; i++) {
            // Kondisi untuk mengecek bilangan ganjil (sisa bagi tidak sama dengan 0)
            if (i % 2 != 0) {
                continue; // Melewati (skip) angka ganjil dan lanjut ke iterasi berikutnya
            }

            // Mencetak angka genap
            System.out.print(i + " ");
        }

        System.out.println(); // Baris baru
    }
}