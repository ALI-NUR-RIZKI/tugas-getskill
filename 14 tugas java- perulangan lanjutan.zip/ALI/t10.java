import java.util.Scanner;

public class t10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Menerima input jumlah sisi dari user
        System.out.print("Input: ");
        int sisi = scanner.nextInt();

        System.out.println("Output:");

        // Loop luar untuk mengontrol baris (i)
        for (int i = 0; i < sisi; i++) {
            // Loop dalam untuk mengontrol kolom (j)
            for (int j = 0; j < sisi; j++) {
                // Cetak bintang hanya di pinggir (baris/kolom pertama & terakhir)
                if (i == 0 || i == sisi - 1 || j == 0 || j == sisi - 1) {
                    System.out.print("* ");
                } else {
                    // Cetak spasi di bagian dalam
                    System.out.print("  ");
                }
            }
            // Pindah ke baris baru setelah satu baris selesai
            System.out.println();
        }

        scanner.close();
    }
}