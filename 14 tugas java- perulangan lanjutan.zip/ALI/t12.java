import java.util.Scanner;

public class t12 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Menerima input ukuran sisi dari user
        System.out.print("Input: ");
        int sisi = scanner.nextInt();

        System.out.println("Output:");

        // Loop luar untuk mengontrol baris (i)
        for (int i = 0; i < sisi; i++) {
            // Loop dalam untuk mengontrol kolom (j)
            for (int j = 0; j < sisi; j++) {
                // Syarat mencetak bintang:
                // 1. i == 0                  -> Sisi atas
                // 2. i == sisi - 1           -> Sisi bawah
                // 3. j == 0                  -> Sisi kiri
                // 4. j == sisi - 1           -> Sisi kanan
                // 5. i == j                  -> Diagonal kiri-atas ke kanan-bawah
                // 6. i + j == sisi - 1       -> Diagonal kanan-atas ke kiri-bawah (Tambahan Silang)
                if (i == 0 || i == sisi - 1 || j == 0 || j == sisi - 1 || i == j || (i + j == sisi - 1)) {
                    System.out.print("* ");
                } else {
                    // Cetak spasi untuk bagian yang kosong
                    System.out.print("  ");
                }
            }
            // Pindah ke baris baru setelah satu baris selesai
            System.out.println();
        }

        scanner.close();
    }
}