import java.util.Scanner;

public class t2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int angka;

        System.out.println("=== PROGRAM INPUT ANGKA BERULANG ===");
        System.out.println("Masukkan angka sembarang (masukkan 0 untuk berhenti):");

        // Perulangan while yang terus berjalan hingga user memasukkan angka 0
        while (true) {
            System.out.print("Masukkan angka: ");
            angka = scanner.nextInt();

            // Cek kondisi berhenti
            if (angka == 0) {
                System.out.println("Program dihentikan karena Anda memasukkan angka 0.");
                break; // Keluar dari perulangan
            }

            System.out.println("Angka yang Anda masukkan: " + angka);
        }

        scanner.close();
    }
}