import java.util.Scanner;

public class t6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int total = 0;

        System.out.println("=== PROGRAM PENJUMLAHAN KELIPATAN 5 ===");
        System.out.println("Masukkan 5 angka satu per satu:");

        // Perulangan untuk menerima 5 kali inputan user
        for (int i = 1; i <= 5; i++) {
            System.out.print("Masukkan angka ke-" + i + ": ");
            int angka = scanner.nextInt();

            // Cek apakah angka BUKAN kelipatan 5 (sisa bagi tidak sama dengan 0)
            if (angka % 5 != 0) {
                continue; // Skip angka yang bukan kelipatan 5
            }

            // Jika kelipatan 5, tambahkan ke variabel total
            total += angka;
        }

        // Menampilkan hasil total penjumlahan
        System.out.println("\nTotal hasil penjumlahan angka kelipatan 5: " + total);

        scanner.close();
    }
}