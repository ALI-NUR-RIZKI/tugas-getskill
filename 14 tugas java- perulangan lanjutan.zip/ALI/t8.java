public class t8 {
    public static void main(String[] args) {
        int baris = 5;
        int kolom = 5;

        // Loop luar untuk mengontrol baris (1 sampai 5)
        for (int i = 1; i <= baris; i++) {
            // Loop dalam untuk mengontrol kolom (1 sampai 5)
            for (int j = 1; j <= kolom; j++) {
                // Perkalian antara indeks baris (i) dan kolom (j)
                int hasil = i * j;
                
                // Menampilkan hasil dengan format rapi menggunakan tab (\t)
                System.out.print(hasil + "\t");
            }
            // Pindah ke baris baru setelah satu baris selesai
            System.out.println();
        }
    }
}